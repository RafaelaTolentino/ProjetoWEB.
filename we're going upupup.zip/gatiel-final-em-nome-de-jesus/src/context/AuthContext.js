import { createContext, useContext, useState, useEffect } from 'react';
import { auth, db } from '../firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [usuario, setUsuario]       = useState(null);
  const [carregando, setCarregando] = useState(true); // aguarda Firebase resolver sessão

  // Escuta mudanças de sessão do Firebase automaticamente
  useEffect(() => {
    const cancelar = onAuthStateChanged(auth, async (firebaseUser) => {
      if (!firebaseUser) {
        setUsuario(null);
        setCarregando(false);
        return;
      }

      // Busca role e nome no Firestore
      const snap = await getDoc(doc(db, 'usuarios', firebaseUser.uid));
      if (snap.exists()) {
        const dados = snap.data();
        setUsuario({
          id:    firebaseUser.uid,
          nome:  dados.nome  || firebaseUser.displayName || 'Usuário',
          email: firebaseUser.email,
          role:  dados.role  || 'user',
        });
      } else {
        // Usuário existe no Auth mas não tem doc no Firestore (ex: primeiro login Google)
        setUsuario({
          id:    firebaseUser.uid,
          nome:  firebaseUser.displayName || 'Usuário',
          email: firebaseUser.email,
          role:  'user',
        });
      }
      setCarregando(false);
    });

    return () => cancelar(); // limpa listener ao desmontar
  }, []);

  // Mantido para uso manual em fluxos especiais (ex: cadastro imediato)
  function login(user) {
    setUsuario(user);
  }

  async function logout() {
    await signOut(auth);
    setUsuario(null);
  }

  // Não renderiza nada até o Firebase confirmar (ou não) a sessão
  if (carregando) {
    return (
      <div className="d-flex justify-content-center align-items-center vh-100">
        <div className="spinner-border" style={{ color: '#e8973c' }} />
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ usuario, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
