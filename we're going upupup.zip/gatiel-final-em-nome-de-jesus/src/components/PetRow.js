// Card visual reutilizável para exibir um pet.
// Props:
//   pet       — objeto com os dados do pet
//   onEditar  — (admin) callback ao clicar em Editar; se ausente, botão não aparece
//   onExcluir — (admin) callback ao clicar em Excluir; se ausente, botão não aparece
//   acoes     — (opcional) elemento React para substituir os botões padrão no rodapé

function PetRow({ pet, onEditar, onExcluir, acoes }) {
  return (
    <div className="col-md-4 col-sm-6 mb-4">
      <div className="card h-100 shadow-sm border-0 position-relative">

        {/* Badge de status */}
        <span className={`badge position-absolute top-0 end-0 m-3 fs-6 ${
          pet.status === 'Disponível' ? 'bg-success'   :
          pet.status === 'Adotado'    ? 'bg-secondary' :
          'bg-warning text-dark'
        }`}>
          {pet.status}
        </span>

        {/* Foto */}
        <div style={{
          height: '240px',
          overflow: 'hidden',
          backgroundColor: '#f8f9fa',
          borderRadius: '8px 8px 0 0'
        }}>
          {pet.fotoUrl ? (
            <img
              src={pet.fotoUrl}
              alt={pet.nome}
              className="w-100 h-100"
              style={{ objectFit: 'cover' }}
            />
          ) : (
            <div className="w-100 h-100 d-flex flex-column align-items-center justify-content-center text-muted">
              <span className="fs-1">📷</span>
              <span className="small">Sem foto cadastrada</span>
            </div>
          )}
        </div>

        {/* Corpo */}
        <div className="card-body d-flex flex-column">
          <h4 className="card-title fw-bold text-dark mb-1">{pet.nome}</h4>
          <p className="text-secondary mb-3 small">
            {pet.especie} {pet.raca ? `• ${pet.raca}` : ''}
          </p>

          <div className="row g-2 mb-4 bg-light p-2 rounded text-center small">
            <div className="col-6 border-end">
              <span className="text-muted d-block">Idade</span>
              <strong>{pet.idade ? `${pet.idade} ano(s)` : '—'}</strong>
            </div>
            <div className="col-6">
              <span className="text-muted d-block">Sexo</span>
              <strong>{pet.sexo || '—'}</strong>
            </div>
          </div>

          {/* Rodapé: usa prop 'acoes' se fornecida; senão botões padrão de admin */}
          <div className="mt-auto">
            {acoes ? acoes : (
              <div className="d-flex gap-2">
                {onEditar && (
                  <button
                    className="btn btn-outline-primary btn-sm flex-grow-1"
                    onClick={() => onEditar(pet)}
                  >
                    ✏️ Editar
                  </button>
                )}
                {onExcluir && (
                  <button
                    className="btn btn-outline-danger btn-sm flex-grow-1"
                    onClick={() => onExcluir(pet.id)}
                  >
                    🗑️ Excluir
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default PetRow;
