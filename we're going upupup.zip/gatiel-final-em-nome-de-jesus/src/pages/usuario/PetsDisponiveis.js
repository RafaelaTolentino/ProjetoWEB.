import { useState, useEffect } from 'react';
import { db } from '../../firebase';
import { collection, getDocs, addDoc } from 'firebase/firestore';
import { useAuth } from '../../context/AuthContext';
import PetRow from '../../components/PetRow';

function PetsDisponiveis() {
  const [pets, setPets]             = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [modalPet, setModalPet]     = useState(null);
  const [mensagem, setMensagem]     = useState('');
  const [enviando, setEnviando]     = useState(false);
  const [sucesso, setSucesso]       = useState('');
  const [erro, setErro]             = useState('');
  const { usuario } = useAuth();

  useEffect(() => {
    async function carregar() {
      const snapshot = await getDocs(collection(db, 'pets'));
      const todos = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setPets(todos.filter(p => p.status === 'Disponível'));
      setCarregando(false);
    }
    carregar();
  }, []);

  function abrirModal(pet) {
    setModalPet(pet); setMensagem(''); setSucesso(''); setErro('');
  }

  async function handleSolicitar() {
    setEnviando(true); setErro('');
    try {
      await addDoc(collection(db, 'requerimentos'), {
        usuarioId:   usuario.id,
        usuarioNome: usuario.nome,
        petId:       modalPet.id,
        petNome:     modalPet.nome,
        petEspecie:  modalPet.especie,
        mensagem:    mensagem.trim(),
        status:      'Pendente',
        dataEnvio:   new Date().toISOString(),
      });
      setSucesso(`Solicitação para adotar ${modalPet.nome} enviada com sucesso!`);
      // Remove o pet da lista local após solicitar
      setPets(prev => prev.filter(p => p.id !== modalPet.id));
      setTimeout(() => setModalPet(null), 2000);
    } catch (err) {
      setErro('Erro ao enviar. Tente novamente.');
    } finally {
      setEnviando(false);
    }
  }

  return (
    <div>
      <h2>🐾 Pets disponíveis para adoção</h2>
      <p className="text-muted mb-4">Encontre seu novo melhor amigo e envie uma solicitação.</p>

      {carregando ? (
        <div className="text-center py-5">
          <div className="spinner-border" style={{ color: '#e8973c' }} />
          <p className="text-muted mt-2">Carregando pets...</p>
        </div>
      ) : pets.length === 0 ? (
        <div className="text-center py-5 card border-0 shadow-sm" style={{ borderRadius: 12 }}>
          <div style={{ fontSize: '3rem' }}>🐾</div>
          <p className="text-muted mt-2 fw-semibold">Nenhum pet disponível no momento.</p>
          <p className="text-muted small">Volte em breve — novos pets são cadastrados regularmente!</p>
        </div>
      ) : (
        <div className="row">
          {pets.map(pet => (
            <PetRow
              key={pet.id}
              pet={pet}
              acoes={
                <button
                  className="btn w-100 text-white fw-semibold"
                  style={{ backgroundColor: '#e8973c', borderRadius: 8 }}
                  onClick={() => abrirModal(pet)}
                >
                  💛 Solicitar adoção
                </button>
              }
            />
          ))}
        </div>
      )}

      {/* Modal de confirmação */}
      {modalPet && (
        <div
          className="modal d-block"
          style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 1050, display: 'flex !important', alignItems: 'center', justifyContent: 'center' }}
          onClick={e => { if (e.target === e.currentTarget) setModalPet(null); }}
        >
          <div className="modal-dialog modal-dialog-centered" style={{ margin: 'auto' }}>
            <div className="modal-content border-0" style={{ borderRadius: 16 }}>
              <div className="modal-header border-0">
                <h5 className="modal-title fw-bold">
                  💛 Solicitar adoção de <span style={{ color: '#e8973c' }}>{modalPet.nome}</span>
                </h5>
                <button className="btn-close" onClick={() => setModalPet(null)} />
              </div>
              <div className="modal-body">
                {sucesso ? (
                  <div className="alert alert-success text-center">✅ {sucesso}</div>
                ) : (
                  <>
                    {erro && <div className="alert alert-danger small">{erro}</div>}
                    <p className="text-muted small mb-3">
                      Adicione uma mensagem opcional explicando por que você seria um bom lar.
                    </p>
                    <label className="form-label fw-semibold">Mensagem (opcional)</label>
                    <textarea
                      className="form-control"
                      rows={4}
                      placeholder={`Ex: Tenho quintal grande e muito amor para dar ao ${modalPet.nome}...`}
                      value={mensagem}
                      onChange={e => setMensagem(e.target.value)}
                    />
                  </>
                )}
              </div>
              {!sucesso && (
                <div className="modal-footer border-0 pt-0">
                  <button className="btn btn-outline-secondary" onClick={() => setModalPet(null)}>
                    Cancelar
                  </button>
                  <button
                    className="btn text-white fw-semibold"
                    style={{ backgroundColor: '#e8973c' }}
                    onClick={handleSolicitar}
                    disabled={enviando}
                  >
                    {enviando ? 'Enviando...' : '✅ Confirmar solicitação'}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default PetsDisponiveis;
