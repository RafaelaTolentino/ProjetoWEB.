import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { auth, db, googleProvider } from '../firebase';
import { signInWithEmailAndPassword, signInWithPopup } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { useAuth } from '../context/AuthContext';

function Login() {
  const [email, setEmail]           = useState('');
  const [senha, setSenha]           = useState('');
  const [erro, setErro]             = useState('');
  const [carregando, setCarregando] = useState(false);
  const { login } = useAuth();
  const navigate  = useNavigate();

  // Redireciona para a rota certa conforme o role
  function redirecionar(role) {
    navigate(role === 'admin' ? '/admin' : '/user/pets');
  }

  // ---------- E-mail / senha ----------
  async function handleLogin(e) {
    e.preventDefault();
    setErro('');
    if (!email || !senha) { setErro('Preencha e-mail e senha.'); return; }

    setCarregando(true);
    try {
      const cred = await signInWithEmailAndPassword(auth, email, senha);
      const snap = await getDoc(doc(db, 'usuarios', cred.user.uid));

      if (!snap.exists()) { setErro('Usuário não encontrado no sistema.'); return; }

      const dados = snap.data();
      login({ id: cred.user.uid, nome: dados.nome, email: dados.email, role: dados.role || 'user' });
      redirecionar(dados.role);
    } catch (err) {
      const mapa = {
        'auth/invalid-credential':   'E-mail ou senha incorretos.',
        'auth/user-not-found':        'E-mail ou senha incorretos.',
        'auth/wrong-password':        'E-mail ou senha incorretos.',
        'auth/invalid-email':         'E-mail inválido.',
        'auth/too-many-requests':     'Muitas tentativas. Aguarde alguns minutos.',
      };
      setErro(mapa[err.code] || 'Erro ao fazer login. Tente novamente.');
    } finally {
      setCarregando(false);
    }
  }

  // ---------- Google ----------
  async function handleGoogle() {
    setErro('');
    setCarregando(true);
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      const uid  = cred.user.uid;
      const ref  = doc(db, 'usuarios', uid);
      const snap = await getDoc(ref);

      if (snap.exists()) {
        // Usuário já cadastrado — só loga
        const dados = snap.data();
        login({ id: uid, nome: dados.nome, email: dados.email, role: dados.role || 'user' });
        redirecionar(dados.role);
      } else {
        // Primeiro acesso via Google — cria doc no Firestore com role 'user'
        const novoUsuario = {
          nome:      cred.user.displayName || 'Usuário Google',
          email:     cred.user.email,
          telefone:  '',
          role:      'user',
          criadoEm:  new Date().toISOString(),
        };
        await setDoc(ref, novoUsuario);
        login({ id: uid, ...novoUsuario });
        redirecionar('user');
      }
    } catch (err) {
      if (err.code === 'auth/popup-closed-by-user') {
        // usuário fechou o popup — não exibe erro
      } else {
        setErro('Erro ao entrar com Google. Tente novamente.');
      }
    } finally {
      setCarregando(false);
    }
  }

  return (
    <div className="d-flex align-items-center justify-content-center vh-100"
      style={{ background: '#fff8f0' }}>
      <div className="card border-0 shadow p-4" style={{ width: 420, borderRadius: 16 }}>

        <div className="text-center mb-4">
          <div style={{ fontSize: '3rem' }}>🐾</div>
          <h3 className="fw-bold" style={{ color: 'rgb(235, 167, 104)' }}>Gatiel Pets</h3>
          <p className="text-muted small mb-0">Sistema de adoção de animais</p>
        </div>

        {erro && <div className="alert alert-danger py-2 small">⚠️ {erro}</div>}

        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <label className="form-label fw-semibold">E-mail</label>
            <input type="email" className="form-control" value={email}
              onChange={e => setEmail(e.target.value)} placeholder="email@exemplo.com" />
          </div>
          <div className="mb-4">
            <label className="form-label fw-semibold">Senha</label>
            <input type="password" className="form-control" value={senha}
              onChange={e => setSenha(e.target.value)} placeholder="••••••" />
          </div>
          <button type="submit" className="btn w-100 text-white fw-bold"
            style={{ backgroundColor: 'rgb(235, 167, 104)', borderRadius: 8, fontSize: '1rem' }}
            disabled={carregando}>
            {carregando ? 'Entrando...' : 'Entrar'}
          </button>
        </form>

        {/* Divisor */}
        <div className="d-flex align-items-center my-3 gap-2">
          <hr className="flex-grow-1 m-0" />
          <span className="text-muted small">ou</span>
          <hr className="flex-grow-1 m-0" />
        </div>

        {/* Botão Google */}
        <button
          className="btn btn-outline-secondary w-100 d-flex align-items-center justify-content-center gap-2 fw-semibold"
          style={{ borderRadius: 8 }}
          onClick={handleGoogle}
          disabled={carregando}
        >
          {/* SVG oficial do Google */}
          <svg width="18" height="18" viewBox="0 0 48 48">
            <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
            <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
            <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
            <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
            <path fill="none" d="M0 0h48v48H0z"/>
          </svg>
          Entrar com Google
        </button>

        <hr className="my-3" />
        <p className="text-center text-muted small mb-0">
          Ainda não tem conta?{' '}
          <Link to="/cadastro" style={{ color: 'rgb(235, 167, 104)', fontWeight: 600 }}>
            Cadastre-se aqui
          </Link>
        </p>
      </div>
    </div>
  );
}

export default Login;
