import { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, getDocs } from 'firebase/firestore';

function Relatorio() {
  const [adocoes, setAdocoes]   = useState([]);
  const [usuarios, setUsuarios] = useState([]);
  const [pets, setPets]         = useState([]);
  const [carregando, setCarregando] = useState(true);

  // Carrega as 3 coleções simultaneamente para fazer o JOIN em memória
  useEffect(() => {
    async function carregarDados() {
      try {
        const [snapUsuarios, snapPets, snapAdocoes] = await Promise.all([
          getDocs(collection(db, 'usuarios')),
          getDocs(collection(db, 'pets')),
          getDocs(collection(db, 'adocoes')),
        ]);

        setUsuarios(snapUsuarios.docs.map(d => ({ id: d.id, ...d.data() })));
        setPets(snapPets.docs.map(d => ({ id: d.id, ...d.data() })));
        setAdocoes(snapAdocoes.docs.map(d => ({ id: d.id, ...d.data() })));
      } catch (erro) {
        console.error("Erro ao carregar relatório:", erro);
      } finally {
        setCarregando(false);
      }
    }
    carregarDados();
  }, []);

  // Lógica do JOIN: mapeia as adoções trazendo os objetos completos de Usuário e Pet
  const dadosRelatorio = adocoes.map(adocao => {
    const usuario = usuarios.find(u => u.id === adocao.usuarioId);
    const pet = pets.find(p => p.id === adocao.petId);
    
    return {
      id: adocao.id,
      usuarioNome: usuario ? usuario.nome : 'Usuário Removido',
      usuarioEmail: usuario ? usuario.email : '—',
      petNome: pet ? pet.nome : 'Pet Removido',
      petEspecie: pet ? pet.especie : '—',
      dataAdocao: adocao.dataAdocao,
      status: adocao.status
    };
  });

  if (carregando) {
    return <div className="text-center mt-5"><div className="spinner-border text-warning"></div></div>;
  }

  return (
    <div className="card p-4 shadow-sm">
      <h2 className="mb-4">📊 Relatório Gerencial de Adoções </h2>
      
      {dadosRelatorio.length === 0 ? (
        <p className="text-muted">Nenhuma adoção realizada até o momento.</p>
      ) : (
        <div className="table-responsive">
          <table className="table table-striped table-hover align-middle">
            <thead className="table-dark">
              <tr>
                <th>Adotante (Usuário)</th>
                <th>E-mail do Adotante</th>
                <th>Animal (Pet)</th>
                <th>Espécie</th>
                <th>Data da Adoção</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {dadosRelatorio.map(item => (
                <tr key={item.id}>
                  <td><strong>{item.usuarioNome}</strong></td>
                  <td>{item.usuarioEmail}</td>
                  <td>{item.petNome}</td>
                  <td>{item.petEspecie}</td>
                  <td>{item.dataAdocao ? new Date(item.dataAdocao + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}</td>
                  <td>
                    <span className={`badge ${
                      item.status === 'Aprovada'   ? 'bg-success' :
                      item.status === 'Cancelada'  ? 'bg-danger' :
                      item.status === 'Concluída'  ? 'bg-secondary' :
                      'bg-warning text-dark'
                    }`}>
                      {item.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default Relatorio;