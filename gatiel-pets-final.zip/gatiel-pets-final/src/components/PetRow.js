function PetRow({ pet, onEditar, onExcluir }) {
  return (
    <div className="col-md-4 col-sm-6 mb-4">
      <div className="card h-100 shadow-sm border-0 position-relative">
        
        {/* Badge de Status no canto superior do card */}
        <span className={`badge position-absolute top-0 end-0 m-3 fs-6 ${
          pet.status === 'Disponível' ? 'bg-success' :
          pet.status === 'Adotado'    ? 'bg-secondary' :
          'bg-warning text-dark'
        }`}>
          {pet.status}
        </span>

        {/* Foto do Pet Grande no topo */}
        <div style={{ height: '240px', overflow: 'hidden', backgroundColor: '#f8f9fa', borderRadius: '8px 8px 0 0' }}>
          {pet.fotoUrl ? (
            <img 
              src={pet.fotoUrl} 
              alt={pet.nome} 
              className="w-100 h-100"
              style={{ objectFit: 'cover' }} 
            />
          ) : (
            <div className="w-100 h-100 d-flex flex-column align-items-center justify-content-center text-muted">
              <span className="fs-1">📷</span>
              <span className="small">Sem foto cadastrada</span>
            </div>
          )}
        </div>

        {/* Informações Abaixo da Foto */}
        <div className="card-body d-flex flex-column">
          <h4 className="card-title fw-bold text-dark mb-1">{pet.nome}</h4>
          <p className="text-secondary mb-3 small">
            {pet.especie} {pet.raca ? `• ${pet.raca}` : ''}
          </p>

          <div className="row g-2 mb-4 bg-light p-2 rounded text-center small">
            <div className="col-6 border-end">
              <span className="text-muted d-block">Idade</span>
              <strong>{pet.idade ? `${pet.idade} ano(s)` : '—'}</strong>
            </div>
            <div className="col-6">
              <span className="text-muted d-block">Sexo</span>
              <strong>{pet.sexo || '—'}</strong>
            </div>
          </div>

          {/* Botões de Ação no rodapé do card */}
          <div className="d-flex gap-2 mt-auto">
            <button 
              className="btn btn-outline-primary btn-sm flex-grow-1"
              onClick={() => onEditar(pet)}
            >
              ✏️ Editar
            </button>
            <button 
              className="btn btn-outline-danger btn-sm flex-grow-1"
              onClick={() => onExcluir(pet.id)}
            >
              🗑️ Excluir
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}

export default PetRow;