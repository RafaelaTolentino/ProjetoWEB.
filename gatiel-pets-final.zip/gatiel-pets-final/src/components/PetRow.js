function PetRow({ pet, onEditar, onExcluir }) {
  return (
    <tr>
      <td>{pet.nome}</td>
      <td>{pet.especie}</td>
      <td>{pet.raca || '—'}</td>
      <td>{pet.idade ? `${pet.idade} ano(s)` : '—'}</td>
      <td>{pet.sexo}</td>
      <td>
        <span className={`badge ${
          pet.status === 'Disponível' ? 'bg-success' :
          pet.status === 'Adotado'    ? 'bg-secondary' :
          'bg-warning text-dark'
        }`}>
          {pet.status}
        </span>
      </td>
      <td>
        <button 
          className="btn btn-primary btn-sm me-2"
          onClick={() => onEditar(pet)}
        >
          ✏️ Editar
        </button>
        <button 
          className="btn btn-danger btn-sm"
          onClick={() => onExcluir(pet.id)}
        >
          🗑️ Excluir
        </button>
      </td>
    </tr>
  );
}

export default PetRow;