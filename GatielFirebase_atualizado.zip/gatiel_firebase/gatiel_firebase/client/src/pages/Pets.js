import { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, addDoc, getDocs, updateDoc, deleteDoc, doc } from 'firebase/firestore';

function Pets() {
  const [pets, setPets]         = useState([]);
  const [editando, setEditando] = useState(null);
  const [nome, setNome]         = useState('');
  const [especie, setEspecie]   = useState('');
  const [raca, setRaca]         = useState('');
  const [idade, setIdade]       = useState('');
  const [sexo, setSexo]         = useState('');
  const [status, setStatus]     = useState('');
  const [erro, setErro]         = useState('');

  // READ — carrega do Firebase ao abrir a página
  useEffect(() => {
    async function carregar() {
      const snapshot = await getDocs(collection(db, 'pets'));
      setPets(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
    }
    carregar();
  }, []);

  // CREATE
  async function handleCadastrar(e) {
    e.preventDefault();
    setErro('');
    if (!nome || !especie || !sexo || !status) {
      setErro('Nome, espécie, sexo e status são obrigatórios.');
      return;
    }
    const novo = { nome, especie, raca, idade, sexo, status };
    const docRef = await addDoc(collection(db, 'pets'), novo);
    setPets([...pets, { id: docRef.id, ...novo }]);
    limparFormulario();
  }

  // Preenche o formulário para editar
  function handlePrepararEdicao(pet) {
    setEditando(pet);
    setNome(pet.nome);
    setEspecie(pet.especie);
    setRaca(pet.raca || '');
    setIdade(pet.idade || '');
    setSexo(pet.sexo || '');
    setStatus(pet.status || '');
    setErro('');
  }

  // UPDATE
  async function handleAtualizar(e) {
    e.preventDefault();
    setErro('');
    if (!nome || !especie || !sexo || !status) {
      setErro('Nome, espécie, sexo e status são obrigatórios.');
      return;
    }
    const dados = { nome, especie, raca, idade, sexo, status };
    await updateDoc(doc(db, 'pets', editando.id), dados);
    setPets(pets.map(p => p.id === editando.id ? { ...p, ...dados } : p));
    limparFormulario();
  }

  // DELETE
  async function handleExcluir(id) {
    if (!window.confirm('Tem certeza que deseja excluir este pet?')) return;
    await deleteDoc(doc(db, 'pets', id));
    setPets(pets.filter(p => p.id !== id));
  }

  function limparFormulario() {
    setEditando(null);
    setNome(''); setEspecie(''); setRaca(''); setIdade(''); setSexo(''); setStatus('');
    setErro('');
  }

  return (
    <div>
      <h2>🐶 Pets</h2>

      <div className="card p-4 mb-4 shadow-sm">
        <h5>{editando ? '✏️ Editar Pet' : '➕ Cadastrar Pet'}</h5>
        {erro && <div className="alert alert-danger">{erro}</div>}

        <form onSubmit={editando ? handleAtualizar : handleCadastrar}>
          <div className="row g-3">
            <div className="col-md-6">
              <label className="form-label">Nome *</label>
              <input className="form-control" value={nome}
                onChange={e => setNome(e.target.value)} placeholder="Nome do pet" />
            </div>
            <div className="col-md-6">
              <label className="form-label">Espécie *</label>
              <select className="form-select" value={especie}
                onChange={e => setEspecie(e.target.value)}>
                <option value="">Selecione...</option>
                <option value="Cachorro">Cachorro</option>
                <option value="Gato">Gato</option>
                <option value="Pássaro">Pássaro</option>
                <option value="Coelho">Coelho</option>
                <option value="Outro">Outro</option>
              </select>
            </div>
            <div className="col-md-6">
              <label className="form-label">Raça</label>
              <input className="form-control" value={raca}
                onChange={e => setRaca(e.target.value)} placeholder="Raça do pet" />
            </div>
            <div className="col-md-2">
              <label className="form-label">Idade</label>
              <input type="number" min="0" className="form-control" value={idade}
                onChange={e => setIdade(e.target.value)} placeholder="Anos" />
            </div>
            <div className="col-md-2">
              <label className="form-label">Sexo *</label>
              <select className="form-select" value={sexo}
                onChange={e => setSexo(e.target.value)}>
                <option value="">Selecione...</option>
                <option value="Macho">Macho</option>
                <option value="Fêmea">Fêmea</option>
              </select>
            </div>
            <div className="col-md-2">
              <label className="form-label">Status *</label>
              <select className="form-select" value={status}
                onChange={e => setStatus(e.target.value)}>
                <option value="">Selecione...</option>
                <option value="Disponível">Disponível</option>
                <option value="Adotado">Adotado</option>
                <option value="Em tratamento">Em tratamento</option>
              </select>
            </div>
          </div>

          <div className="mt-3 d-flex gap-2">
            <button type="submit" className="btn text-white" style={{ backgroundColor: '#e8973c' }}>
              {editando ? 'Salvar Alterações' : 'Cadastrar'}
            </button>
            {editando && (
              <button type="button" className="btn btn-secondary" onClick={limparFormulario}>
                Cancelar
              </button>
            )}
          </div>
        </form>
      </div>

      <div className="card p-4 shadow-sm">
        <h5>Lista de Pets</h5>
        {pets.length === 0 ? (
          <p className="text-muted">Nenhum pet cadastrado.</p>
        ) : (
          <table className="table table-hover align-middle">
            <thead className="table-warning">
              <tr>
                <th>Nome</th><th>Espécie</th><th>Raça</th><th>Idade</th><th>Sexo</th><th>Status</th><th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {pets.map(p => (
                <tr key={p.id}>
                  <td>{p.nome}</td>
                  <td>{p.especie}</td>
                  <td>{p.raca || '—'}</td>
                  <td>{p.idade ? `${p.idade} ano(s)` : '—'}</td>
                  <td>{p.sexo}</td>
                  <td>
                    <span className={`badge ${
                      p.status === 'Disponível' ? 'bg-success' :
                      p.status === 'Adotado'    ? 'bg-secondary' :
                      'bg-warning text-dark'
                    }`}>
                      {p.status}
                    </span>
                  </td>
                  <td>
                    <button className="btn btn-primary btn-sm me-2"
                      onClick={() => handlePrepararEdicao(p)}>✏️ Editar</button>
                    <button className="btn btn-danger btn-sm"
                      onClick={() => handleExcluir(p.id)}>🗑️ Excluir</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default Pets;
