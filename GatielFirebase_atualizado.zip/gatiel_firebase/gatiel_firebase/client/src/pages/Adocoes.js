import { useState, useEffect } from 'react';
import { db } from '../firebase';
import {
  collection, addDoc, getDocs, updateDoc, deleteDoc, doc
} from 'firebase/firestore';

function Adocoes() {
  const [adocoes, setAdocoes]       = useState([]);
  const [usuarios, setUsuarios]     = useState([]);
  const [pets, setPets]             = useState([]);
  const [editando, setEditando]     = useState(null);
  const [usuarioId, setUsuarioId]   = useState('');
  const [petId, setPetId]           = useState('');
  const [dataAdocao, setDataAdocao] = useState('');
  const [status, setStatus]         = useState('');
  const [erro, setErro]             = useState('');

  // READ — carrega usuários, pets e adoções do Firebase ao abrir a página
  useEffect(() => {
    async function carregar() {
      const [snapUsuarios, snapPets, snapAdocoes] = await Promise.all([
        getDocs(collection(db, 'usuarios')),
        getDocs(collection(db, 'pets')),
        getDocs(collection(db, 'adocoes')),
      ]);

      setUsuarios(snapUsuarios.docs.map(d => ({ id: d.id, ...d.data() })));
      setPets(snapPets.docs.map(d => ({ id: d.id, ...d.data() })));
      setAdocoes(snapAdocoes.docs.map(d => ({ id: d.id, ...d.data() })));
    }
    carregar();
  }, []);

  // Helpers para buscar nome pelo id
  function nomeUsuario(id) {
    const u = usuarios.find(u => u.id === id);
    return u ? u.nome : '—';
  }
  function nomePet(id) {
    const p = pets.find(p => p.id === id);
    return p ? `${p.nome} (${p.especie})` : '—';
  }

  // CREATE
  async function handleCadastrar(e) {
    e.preventDefault();
    setErro('');
    if (!usuarioId || !petId || !dataAdocao || !status) {
      setErro('Todos os campos são obrigatórios.');
      return;
    }
    const novo = { usuarioId, petId, dataAdocao, status };
    const docRef = await addDoc(collection(db, 'adocoes'), novo);
    setAdocoes([...adocoes, { id: docRef.id, ...novo }]);
    limparFormulario();
  }

  // Preenche o formulário para editar
  function handlePrepararEdicao(adocao) {
    setEditando(adocao);
    setUsuarioId(adocao.usuarioId);
    setPetId(adocao.petId);
    setDataAdocao(adocao.dataAdocao);
    setStatus(adocao.status);
    setErro('');
  }

  // UPDATE
  async function handleAtualizar(e) {
    e.preventDefault();
    setErro('');
    if (!usuarioId || !petId || !dataAdocao || !status) {
      setErro('Todos os campos são obrigatórios.');
      return;
    }
    const dados = { usuarioId, petId, dataAdocao, status };
    await updateDoc(doc(db, 'adocoes', editando.id), dados);
    setAdocoes(adocoes.map(a => a.id === editando.id ? { ...a, ...dados } : a));
    limparFormulario();
  }

  // DELETE
  async function handleExcluir(id) {
    if (!window.confirm('Tem certeza que deseja excluir esta adoção?')) return;
    await deleteDoc(doc(db, 'adocoes', id));
    setAdocoes(adocoes.filter(a => a.id !== id));
  }

  function limparFormulario() {
    setEditando(null);
    setUsuarioId(''); setPetId(''); setDataAdocao(''); setStatus('');
    setErro('');
  }

  return (
    <div>
      <h2>📋 Adoções</h2>

      <div className="card p-4 mb-4 shadow-sm">
        <h5>{editando ? '✏️ Editar Adoção' : '➕ Registrar Adoção'}</h5>
        {erro && <div className="alert alert-danger">{erro}</div>}

        <form onSubmit={editando ? handleAtualizar : handleCadastrar}>
          <div className="row g-3">
            <div className="col-md-6">
              <label className="form-label">Usuário (Adotante) *</label>
              <select className="form-select" value={usuarioId}
                onChange={e => setUsuarioId(e.target.value)}>
                <option value="">Selecione o usuário...</option>
                {usuarios.map(u => (
                  <option key={u.id} value={u.id}>{u.nome} — {u.email}</option>
                ))}
              </select>
            </div>
            <div className="col-md-6">
              <label className="form-label">Pet *</label>
              <select className="form-select" value={petId}
                onChange={e => setPetId(e.target.value)}>
                <option value="">Selecione o pet...</option>
                {pets.map(p => (
                  <option key={p.id} value={p.id}>{p.nome} — {p.especie} ({p.status})</option>
                ))}
              </select>
            </div>
            <div className="col-md-6">
              <label className="form-label">Data da Adoção *</label>
              <input type="date" className="form-control" value={dataAdocao}
                onChange={e => setDataAdocao(e.target.value)} />
            </div>
            <div className="col-md-6">
              <label className="form-label">Status *</label>
              <select className="form-select" value={status}
                onChange={e => setStatus(e.target.value)}>
                <option value="">Selecione...</option>
                <option value="Pendente">Pendente</option>
                <option value="Aprovada">Aprovada</option>
                <option value="Cancelada">Cancelada</option>
                <option value="Concluída">Concluída</option>
              </select>
            </div>
          </div>

          <div className="mt-3 d-flex gap-2">
            <button type="submit" className="btn text-white" style={{ backgroundColor: '#e8973c' }}>
              {editando ? 'Salvar Alterações' : 'Registrar'}
            </button>
            {editando && (
              <button type="button" className="btn btn-secondary" onClick={limparFormulario}>
                Cancelar
              </button>
            )}
          </div>
        </form>
      </div>

      <div className="card p-4 shadow-sm">
        <h5>Lista de Adoções</h5>
        {adocoes.length === 0 ? (
          <p className="text-muted">Nenhuma adoção registrada.</p>
        ) : (
          <table className="table table-hover align-middle">
            <thead className="table-warning">
              <tr>
                <th>Usuário</th><th>Pet</th><th>Data da Adoção</th><th>Status</th><th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {adocoes.map(a => (
                <tr key={a.id}>
                  <td>{nomeUsuario(a.usuarioId)}</td>
                  <td>{nomePet(a.petId)}</td>
                  <td>{a.dataAdocao ? new Date(a.dataAdocao + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}</td>
                  <td>
                    <span className={`badge ${
                      a.status === 'Aprovada'   ? 'bg-success' :
                      a.status === 'Cancelada'  ? 'bg-danger' :
                      a.status === 'Concluída'  ? 'bg-secondary' :
                      'bg-warning text-dark'
                    }`}>
                      {a.status}
                    </span>
                  </td>
                  <td>
                    <button className="btn btn-primary btn-sm me-2"
                      onClick={() => handlePrepararEdicao(a)}>✏️ Editar</button>
                    <button className="btn btn-danger btn-sm"
                      onClick={() => handleExcluir(a.id)}>🗑️ Excluir</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default Adocoes;
