import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import RotaProtegida from './components/RotaProtegida';
import Navbar from './components/Navbar';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Usuarios from './pages/Usuarios';
import Pets from './pages/Pets';
import Adocoes from './pages/Adocoes';
import Relatorio from './pages/Relatorio';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';

function Layout({ children }) {
  return (
    <>
      <Navbar />
      {children}
    </>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<RotaProtegida><Layout><Dashboard /></Layout></RotaProtegida>} />
          <Route path="/usuarios" element={<RotaProtegida><Layout><Usuarios /></Layout></RotaProtegida>} />
          <Route path="/pets" element={<RotaProtegida><Layout><Pets /></Layout></RotaProtegida>} />
          <Route path="/adocoes" element={<RotaProtegida><Layout><Adocoes /></Layout></RotaProtegida>} />
          <Route path="/relatorio" element={<RotaProtegida><Layout><Relatorio /></Layout></RotaProtegida>} />
          <Route path="*" element={<Navigate to="/login" />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
