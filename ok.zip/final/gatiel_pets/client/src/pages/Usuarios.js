import React, { useState } from 'react';

// Formulário de Cadastro 
function FormularioUsuario({ aoSalvar }) {
  const [values, setValues] = useState({ nome: '', email: '', senha: '', telefone: '' });
  const [erro, setErro] = useState('');

  const handleChange = (e) => {
    setValues((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setErro('');

    if (!values.nome || !values.email || !values.senha) {
      setErro('Nome, e-mail e senha são obrigatórios.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(values.email)) {
      setErro('Informe um e-mail válido.');
      return;
    }

    aoSalvar(values);
    setValues({ nome: '', email: '', senha: '', telefone: '' });
  };

  return (
    <div className="card card-gatiel p-4 mb-4">
      <h3 className="mb-3">➕ Cadastrar Usuário</h3>
      {erro && <div className="alert alert-danger py-2">{erro}</div>}
      <form onSubmit={handleSubmit}>
        <div className="row g-3">
          <div className="col-md-6">
            <label className="form-label fw-semibold">Nome *</label>
            <input type="text" name="nome" className="form-control"
              value={values.nome} onChange={handleChange} placeholder="Nome completo" />
          </div>
          <div className="col-md-6">
            <label className="form-label fw-semibold">E-mail *</label>
            <input type="email" name="email" className="form-control"
              value={values.email} onChange={handleChange} placeholder="email@exemplo.com" />
          </div>
          <div className="col-md-6">
            <label className="form-label fw-semibold">Senha *</label>
            <input type="password" name="senha" className="form-control"
              value={values.senha} onChange={handleChange} placeholder="Senha de acesso" />
          </div>
          <div className="col-md-6">
            <label className="form-label fw-semibold">Telefone</label>
            <input type="text" name="telefone" className="form-control"
              value={values.telefone} onChange={handleChange} placeholder="(11) 99999-0000" />
          </div>
        </div>
        <button type="submit" className="btn btn-gatiel mt-3">Cadastrar</button>
      </form>
    </div>
  );
}

// Linha de Usuário (componente reutilizável com edição inline)
function LinhaUsuario({ usuario, aoAtualizar, aoExcluir }) {
  const [editando, setEditando] = useState(false);
  const [editData, setEditData] = useState({
    nome: usuario.nome,
    email: usuario.email,
    telefone: usuario.telefone || '',
  });

  const handleSalvar = () => {
    aoAtualizar(usuario.id, editData);
    setEditando(false);
  };

  return (
    <tr>
      {editando ? (
        <>
          <td>{usuario.id}</td>
          <td><input className="form-control form-control-sm" value={editData.nome}
            onChange={(e) => setEditData({ ...editData, nome: e.target.value })} /></td>
          <td><input className="form-control form-control-sm" value={editData.email}
            onChange={(e) => setEditData({ ...editData, email: e.target.value })} /></td>
          <td><input className="form-control form-control-sm" value={editData.telefone}
            onChange={(e) => setEditData({ ...editData, telefone: e.target.value })} /></td>
          <td>
            <button className="btn btn-success btn-sm me-1" onClick={handleSalvar}>✅ Salvar</button>
            <button className="btn btn-secondary btn-sm" onClick={() => setEditando(false)}>Cancelar</button>
          </td>
        </>
      ) : (
        <>
          <td>{usuario.id}</td>
          <td>{usuario.nome}</td>
          <td>{usuario.email}</td>
          <td>{usuario.telefone || '—'}</td>
          <td>
            <button className="btn btn-primary btn-sm me-1" onClick={() => setEditando(true)}>✏️ Editar</button>
            <button className="btn btn-danger btn-sm" onClick={() => aoExcluir(usuario.id)}>🗑️ Excluir</button>
          </td>
        </>
      )}
    </tr>
  );
}

// Página Principal
function Usuarios() {
  const [usuarios, setUsuarios] = useState(() => {
    const salvo = localStorage.getItem('gatiel_usuarios');
    return salvo ? JSON.parse(salvo) : [];
  });

  const salvar = (lista) => {
    setUsuarios(lista);
    localStorage.setItem('gatiel_usuarios', JSON.stringify(lista));
  };

  const handleCadastrar = (novo) => {
    salvar([...usuarios, { ...novo, id: Date.now() }]);
  };

  const handleAtualizar = (id, dados) => {
    salvar(usuarios.map((u) => (u.id === id ? { ...u, ...dados } : u)));
  };

  const handleExcluir = (id) => {
    if (!window.confirm('Tem certeza que deseja excluir este usuário?')) return;
    salvar(usuarios.filter((u) => u.id !== id));
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">👤 Gerenciar Usuários</h2>
      <FormularioUsuario aoSalvar={handleCadastrar} />
      <div className="card card-gatiel p-4">
        <h3 className="mb-3">📋 Lista de Usuários</h3>
        {usuarios.length === 0 ? (
          <p className="text-muted">Nenhum usuário cadastrado ainda.</p>
        ) : (
          <div className="table-responsive">
            <table className="table table-hover align-middle">
              <thead className="thead-gatiel">
                <tr>
                  <th>#</th><th>Nome</th><th>E-mail</th><th>Telefone</th><th>Ações</th>
                </tr>
              </thead>
              <tbody>
                {usuarios.map((u) => (
                  <LinhaUsuario key={u.id} usuario={u}
                    aoAtualizar={handleAtualizar} aoExcluir={handleExcluir} />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default Usuarios;
