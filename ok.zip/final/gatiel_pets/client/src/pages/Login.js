import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function Login() {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    setErro('');

    if (!email || !senha) {
      setErro('Preencha o e-mail e a senha.');
      return;
    }

    // Login simulado — sem backend
    if (email === 'admin@gatiel.com' && senha === '1234') {
      login({ id: 1, nome: 'Admin', email });
      navigate('/');
    } else {
      setErro('E-mail ou senha incorretos.');
    }
  };

  return (
    <div
      className="d-flex align-items-center justify-content-center vh-100"
      style={{ backgroundColor: '#fdf8f3' }}
    >
      <div className="card card-gatiel p-4" style={{ width: '100%', maxWidth: '420px' }}>
        <div className="text-center mb-4">
          <h1 style={{ fontSize: '3rem' }}>🐾</h1>
          <h2 className="fw-bold" style={{ color: 'rgb(235,167,104)' }}>Gatiel Pets</h2>
          <p className="text-muted" style={{ fontSize: '0.9rem' }}>Faça login para continuar</p>
        </div>

        {erro && <div className="alert alert-danger py-2">{erro}</div>}

        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <label className="form-label fw-semibold">E-mail</label>
            <input
              type="email"
              className="form-control"
              placeholder="admin@gatiel.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="mb-4">
            <label className="form-label fw-semibold">Senha</label>
            <input
              type="password"
              className="form-control"
              placeholder="••••••••"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
            />
          </div>
          <button type="submit" className="btn btn-gatiel w-100">
            Entrar
          </button>
        </form>

        <p className="text-center text-muted mt-3" style={{ fontSize: '0.8rem' }}>
          Acesso: admin@gatiel.com / 1234
        </p>
      </div>
    </div>
  );
}

export default Login;
