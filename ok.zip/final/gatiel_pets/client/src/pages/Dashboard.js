import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function Dashboard() {
  const { usuario } = useAuth();

  return (
    <div className="container mt-5">
      <div className="text-center mb-5">
        <h2>Bem-vindo, {usuario?.nome}! 🐾</h2>
        <p className="text-muted">Painel de administração — Gatiel Pets</p>
      </div>

      <div className="row justify-content-center g-4">
        <div className="col-md-3">
          <div className="card card-gatiel text-center p-4 h-100">
            <div style={{ fontSize: '3rem' }}>👤</div>
            <h5 className="mt-2">Usuários</h5>
            <p className="text-muted">Gerencie os usuários do sistema</p>
            <Link to="/usuarios" className="btn btn-gatiel mt-auto">Acessar</Link>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card card-gatiel text-center p-4 h-100">
            <div style={{ fontSize: '3rem' }}>🐶</div>
            <h5 className="mt-2">Pets</h5>
            <p className="text-muted">Gerencie os pets cadastrados</p>
            <Link to="/pets" className="btn btn-gatiel mt-auto">Acessar</Link>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card card-gatiel text-center p-4 h-100">
            <div style={{ fontSize: '3rem' }}>📋</div>
            <h5 className="mt-2">Adoções</h5>
            <p className="text-muted">Gerencie as adoções realizadas</p>
            <Link to="/adocoes" className="btn btn-gatiel mt-auto">Acessar</Link>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card card-gatiel text-center p-4 h-100">
            <div style={{ fontSize: '3rem' }}>📊</div>
            <h5 className="mt-2">Relatório</h5>
            <p className="text-muted">Pets por dono (JOIN)</p>
            <Link to="/relatorio" className="btn btn-gatiel mt-auto">Acessar</Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
