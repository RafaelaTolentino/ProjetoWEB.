import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { auth, db, googleProvider } from '../firebase';
import {
  signInWithEmailAndPassword,
  signInWithPopup,
  sendPasswordResetEmail,
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { useAuth } from '../context/AuthContext';

// Página de Login. Cobre 3 fluxos diferentes na mesma tela:
//   1) Login tradicional com e-mail + senha
//   2) Login com a conta do Google (1 clique)
//   3) "Esqueci minha senha" (envia e-mail de redefinição)
function Login() {
  // Campos do formulário de login tradicional
  const [email, setEmail]               = useState('');
  const [senha, setSenha]               = useState('');
  const [erro, setErro]                 = useState('');       // mensagem de erro exibida na tela
  const [carregando, setCarregando]     = useState(false);    // true enquanto aguarda resposta do Firebase (desabilita botões)

  // Estados específicos da tela de "Esqueci minha senha"
  const [modoRecuperar, setModoRecuperar] = useState(false);   // true = mostra o formulário de recuperação em vez do login
  const [emailRecuperar, setEmailRecuperar] = useState('');
  const [msgRecuperar, setMsgRecuperar]   = useState('');      // mensagem de sucesso
  const [erroRecuperar, setErroRecuperar] = useState('');
  const [enviando, setEnviando]           = useState(false);   // true enquanto o e-mail de redefinição está sendo enviado

  const { login } = useAuth();   // função do AuthContext para registrar manualmente quem logou
  const navigate  = useNavigate();

  // Decide para onde mandar a pessoa depois do login, de acordo com o
  // papel (role) salvo no Firestore: admin vai para o painel
  // administrativo, qualquer outro papel vai para a lista de pets.
  function redirecionar(role) {
    navigate(role === 'admin' ? '/admin' : '/user/pets');
  }

  // ---------- Login com e-mail / senha ----------
  async function handleLogin(e) {
    e.preventDefault(); // evita que o navegador recarregue a página ao enviar o formulário
    setErro('');
    if (!email || !senha) { setErro('Preencha e-mail e senha.'); return; }

    setCarregando(true);
    try {
      // 1) Autentica no Firebase Authentication (confere e-mail/senha)
      const cred = await signInWithEmailAndPassword(auth, email, senha);
      // 2) Busca os dados extras (nome, papel) no Firestore, usando o
      //    uid retornado pela autenticação como identificador do documento
      const snap = await getDoc(doc(db, 'usuarios', cred.user.uid));
      
      if (snap.exists()) {
        const dados = snap.data();
        // Atualiza o estado global de quem está logado (AuthContext)
        login({ id: cred.user.uid, email: cred.user.email, ...dados });
        redirecionar(dados.role);
      } else {
        // Caso raro: existe login no Authentication mas não há
        // documento correspondente no Firestore — assume papel "user"
        login({ id: cred.user.uid, email: cred.user.email, role: 'user' });
        redirecionar('user');
      }
    } catch (err) {
      // Traduz os códigos de erro mais comuns do Firebase para
      // mensagens em português; qualquer outro erro mostra a mensagem
      // bruta do Firebase como fallback
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        setErro('E-mail ou senha inválidos.');
      } else {
        setErro('Erro ao fazer login: ' + err.message);
      }
    } finally {
      setCarregando(false); // libera os botões independentemente de sucesso ou erro
    }
  }

  // ---------- Login com Google ----------
  async function handleGoogle() {
    setErro('');
    setCarregando(true);
    try {
      // Abre o popup de login do Google e aguarda a pessoa escolher a conta
      const result = await signInWithPopup(auth, googleProvider);
      const userRef = doc(db, 'usuarios', result.user.uid);
      const snap = await getDoc(userRef);

      if (!snap.exists()) {
        // Primeira vez que essa conta Google é usada no site: cria o
        // documento correspondente no Firestore automaticamente, já
        // como usuário comum ('user')
        const novoUser = {
          nome: result.user.displayName || 'Usuário Google',
          email: result.user.email,
          role: 'user',
          criadoEm: new Date().toISOString()
        };
        await setDoc(userRef, novoUser);
        login({ id: result.user.uid, ...novoUser });
        redirecionar('user');
      } else {
        // Conta já tinha sido usada antes: só lê os dados existentes
        const dados = snap.data();
        login({ id: result.user.uid, ...dados });
        redirecionar(dados.role);
      }
    } catch (err) {
      setErro('Erro com login Google: ' + err.message);
    } finally {
      setCarregando(false);
    }
  }

  // ---------- Recuperar Senha ----------
  // Dispara o e-mail oficial do Firebase com o link de redefinição de senha
  async function handleRecuperar(e) {
    e.preventDefault();
    setErroRecuperar('');
    setMsgRecuperar('');
    if (!emailRecuperar) { setErroRecuperar('Digite seu e-mail.'); return; }

    setEnviando(true);
    try {
      await sendPasswordResetEmail(auth, emailRecuperar);
      setMsgRecuperar('E-mail de redefinição enviado com sucesso! Verifique sua caixa de entrada.');
    } catch (err) {
      setErroRecuperar('Erro ao enviar e-mail: ' + err.message);
    } finally {
      setEnviando(false);
    }
  }

  // ------------------------------------------------------------
  // Renderização condicional: se `modoRecuperar` for true, mostra
  // APENAS o cartão de recuperação de senha (em vez do formulário de
  // login). É um "return" antecipado — o restante da função (o
  // formulário de login) só é executado se modoRecuperar for false.
  // ------------------------------------------------------------
  if (modoRecuperar) {
    return (
      <div className="container d-flex align-items-center justify-content-center vh-100">
        <div className="card p-4 shadow border-0" style={{ width: '100%', maxWidth: 420, borderRadius: 16 }}>
          <h3 className="fw-bold text-center mb-3" style={{ color: '#e8973c' }}>🔒 Recuperar Senha</h3>
          <p className="text-muted small text-center mb-4">Insira o e-mail cadastrado para receber as instruções de redefinição.</p>
          
          {erroRecuperar && <div className="alert alert-danger small">{erroRecuperar}</div>}
          {msgRecuperar && <div className="alert alert-success small">{msgRecuperar}</div>}

          <form onSubmit={handleRecuperar}>
            <div className="mb-4">
              <label className="form-label fw-semibold">E-mail</label>
              <input type="email" className="form-control" placeholder="seuemail@exemplo.com"
                value={emailRecuperar} onChange={e => setEmailRecuperar(e.target.value)} disabled={enviando} />
            </div>
            <button type="submit" className="btn w-100 text-white fw-bold mb-3" style={{ backgroundColor: '#e8973c', borderRadius: 8 }} disabled={enviando}>
              {enviando ? 'Enviando...' : 'Enviar Link'}
            </button>
            <button type="button" className="btn btn-light w-100 border fw-semibold" style={{ borderRadius: 8 }} onClick={() => setModoRecuperar(false)} disabled={enviando}>
              Voltar para o Login
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Formulário principal de login (mostrado quando modoRecuperar é false)
  return (
    <div className="container d-flex align-items-center justify-content-center vh-100">
      <div className="card p-4 shadow border-0" style={{ width: '100%', maxWidth: 420, borderRadius: 16 }}>
        <div className="text-center mb-4">
          <span style={{ fontSize: '3.5rem' }}>🐾</span>
          <h3 className="fw-bold mt-2" style={{ color: '#e8973c' }}>Bem-vindo de volta!</h3>
          <p className="text-muted small">Faça login para continuar</p>
        </div>

        {erro && <div className="alert alert-danger small">{erro}</div>}

        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <label className="form-label fw-semibold">E-mail</label>
            <input type="email" className="form-control" placeholder="nome@exemplo.com"
              value={email} onChange={e => setEmail(e.target.value)} style={{ borderRadius: 8 }} />
          </div>

          <div className="mb-2">
            <div className="d-flex justify-content-between align-items-center mb-1">
              <label className="form-label fw-semibold mb-0">Senha</label>
              <button type="button" className="btn btn-link p-0 text-decoration-none small fw-semibold" style={{ color: '#e8973c' }} onClick={() => setModoRecuperar(true)}>
                Esqueceu a senha?
              </button>
            </div>
            <input type="password" className="form-control" placeholder="••••••••"
              value={senha} onChange={e => setSenha(e.target.value)} style={{ borderRadius: 8 }} />
          </div>

          <button type="submit" className="btn w-100 text-white fw-bold mt-4 mb-3" style={{ backgroundColor: '#e8973c', borderRadius: 8, padding: '10px' }} disabled={carregando}>
            {carregando ? 'Entrando...' : 'Entrar'}
          </button>

          <div className="position-relative my-4 text-center">
            <hr className="text-muted opacity-25" />
            <span className="position-absolute top-50 start-50 translate-middle bg-white px-3 text-muted small fw-semibold">OU</span>
          </div>

          {/* Botão de login com Google — o SVG abaixo é só o logo
              oficial colorido do Google, desenhado em 4 partes (uma
              para cada cor) */}
          <button type="button" className="btn btn-outline-secondary w-100 d-flex align-items-center justify-content-center gap-2 fw-semibold" style={{ borderRadius: 8 }} onClick={handleGoogle} disabled={carregando}>
            <svg width="18" height="18" viewBox="0 0 48 48">
              <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
              <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
              <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
              <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.46-9.91l-7.97 6.19C6.51 42.62 14.62 48 24 48z"/>
            </svg>
            Entrar com o Google
          </button>
        </form>

        <p className="text-center text-muted small mt-4 mb-0">
          Não tem uma conta? <Link to="/cadastro" className="fw-bold text-decoration-none" style={{ color: '#e8973c' }}>Cadastre-se</Link>
        </p>
      </div>
    </div>
  );
}

export default Login;