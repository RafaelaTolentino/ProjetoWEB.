import { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, getDocs, updateDoc, deleteDoc, doc, setDoc } from 'firebase/firestore';
// Importações necessárias para criar o utilizador no Firebase Auth de forma secundária
import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';

// Copie as mesmas configurações do seu arquivo firebase.js para esta app secundária
const firebaseConfig = {
  apiKey: "AIzaSyDxnTDZHY-Y9csnbhzuzxmcdLLfsCSLJPI",
  authDomain: "gatiel-fa7d9.firebaseapp.com",
  projectId: "gatiel-fa7d9",
  storageBucket: "gatiel-fa7d9.firebasestorage.app",
  messagingSenderId: "322054187894",
  appId: "1:322054187894:web:618c4eb3098f5d36222857"
};

// Inicializa uma app secundária isolada para não deslogar o administrador atual
const secondaryApp = initializeApp(firebaseConfig, "SecondaryAuth");
const secondaryAuth = getAuth(secondaryApp);

function Usuarios() {
  const [usuarios, setUsuarios]   = useState([]);
  const [editando, setEditando]   = useState(null);
  const [nome, setNome]           = useState('');
  const [email, setEmail]         = useState('');
  const [senha, setSenha]         = useState('');
  const [telefone, setTelefone]   = useState('');
  const [role, setRole]           = useState('user'); // Problema 5: Estado para controlar a permissão (padrão: user)
  const [erro, setErro]           = useState('');
  const [sucesso, setSucesso]     = useState('');

  // Carrega todos os utilizadores ao iniciar a página
  useEffect(() => {
    async function carregar() {
      const snapshot = await getDocs(collection(db, 'usuarios'));
      const lista = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setUsuarios(lista);
    }
    carregar();
  }, []);

  // Limpa o formulário após operações
  function limparFormulario() {
    setEditando(null);
    setNome('');
    setEmail('');
    setSenha('');
    setTelefone('');
    setRole('user');
    setErro('');
  }

  // Problemas 1 e 5: Manipulação do Cadastro de Usuários
  async function handleCadastrar(e) {
    e.preventDefault();
    setErro('');
    setSucesso('');

    if (!nome || !email) {
      setErro('Nome e E-mail são obrigatórios.');
      return;
    }

    try {
      if (editando) {
        // Fluxo de Edição existente
        await updateDoc(doc(db, 'usuarios', editando.id), {
          nome, email, telefone, role
        });
        setUsuarios(usuarios.map(u => u.id === editando.id ? { ...u, nome, email, telefone, role } : u));
        setSucesso('Usuário atualizado com sucesso!');
        limparFormulario();
      } else {
        // Fluxo de Criação Novo
        if (!senha || senha.length < 6) {
          setErro('A senha é obrigatória e deve ter pelo menos 6 caracteres para novos usuários.');
          return;
        }

        // 1. Criar no Firebase Authentication usando a app secundária (Evita deslogar o admin)
        const credencial = await createUserWithEmailAndPassword(secondaryAuth, email, senha);
        const uid = credencial.user.uid;

        // 2. Gravar no Firestore usando o mesmo UID do Authentication
        const novoUsuario = {
          nome,
          email,
          telefone,
          role, // Problema 5: Envia o nível de acesso escolhido pelo administrador
          criadoEm: new Date().toISOString()
        };

        await setDoc(doc(db, 'usuarios', uid), novoUsuario);
        setUsuarios([{ id: uid, ...novoUsuario }, ...usuarios]);
        setSucesso('Novo usuário registado com sucesso no sistema!');
        limparFormulario();
      }
    } catch (err) {
      console.error(err);
      if (err.code === 'auth/email-already-in-check' || err.code === 'auth/email-already-in-use') {
        setErro('Este e-mail já está em uso por outro usuário.');
      } else {
        setErro('Erro ao processar requisição: ' + err.message);
      }
    }
  }

  function handlePrepararEdicao(u) {
    setEditando(u);
    setNome(u.nome || '');
    setEmail(u.email || '');
    setTelefone(u.telefone || '');
    setRole(u.role || 'user');
  }

  async function handleExcluir(id) {
    if (!window.confirm('Deseja excluir este usuário do Banco de Dados?')) return;
    try {
      await deleteDoc(doc(db, 'usuarios', id));
      setUsuarios(usuarios.filter(u => u.id !== id));
    } catch (err) {
      setErro('Erro ao excluir: ' + err.message);
    }
  }

  return (
    <div className="container py-4">
      <div className="card p-4 shadow-sm border-0 mb-4" style={{ borderRadius: 12 }}>
        <h4 className="fw-bold text-dark mb-3">{editando ? '✏️ Editar Usuário' : '🛠️ Cadastrar Novo Usuário'}</h4>
        {erro && <div className="alert alert-danger">{erro}</div>}
        {sucesso && <div className="alert alert-success">{sucesso}</div>}

        <form onSubmit={handleCadastrar} className="row g-3">
          <div className="col-md-6">
            <label className="form-label fw-semibold">Nome *</label>
            <input type="text" className="form-control" value={nome} onChange={e => setNome(e.target.value)} />
          </div>
          <div className="col-md-6">
            <label className="form-label fw-semibold">E-mail *</label>
            <input type="email" className="form-control" value={email} onChange={e => setEmail(e.target.value)} disabled={!!editando} />
          </div>
          {!editando && (
            <div className="col-md-4">
              <label className="form-label fw-semibold">Senha Inicial *</label>
              <input type="password" className="form-control" value={senha} onChange={e => setSenha(e.target.value)} placeholder="Mín. 6 dígitos" />
            </div>
          )}
          <div className={editando ? "col-md-6" : "col-md-4"}>
            <label className="form-label fw-semibold">Telefone</label>
            <input type="text" className="form-control" value={telefone} onChange={e => setTelefone(e.target.value)} />
          </div>
          
          {/* Problema 5: Campo Select adicionado para escolha de Permissão */}
          <div className={editando ? "col-md-6" : "col-md-4"}>
            <label className="form-label fw-semibold">Nível de Permissão *</label>
            <select className="form-select" value={role} onChange={e => setRole(e.target.value)}>
              <option value="user">Usuário Comum</option>
              <option value="admin">Administrador</option>
            </select>
          </div>

          <div className="col-12 mt-4">
            <button type="submit" className="btn btn-warning text-white fw-bold me-2">
              {editando ? 'Salvar Alterações' : 'Cadastrar'}
            </button>
            {editando && <button type="button" className="btn btn-light border" onClick={limparFormulario}>Cancelar</button>}
          </div>
        </form>
      </div>

      <div className="card p-4 shadow-sm border-0" style={{ borderRadius: 12 }}>
        <h5 className="fw-bold text-dark mb-3">Lista de Utilizadores</h5>
        <div className="table-responsive">
          <table className="table table-hover align-middle">
            <thead className="table-warning">
              <tr>
                <th>Nome</th><th>E-mail</th><th>Telefone</th><th>Permissão</th><th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {usuarios.map(u => (
                <tr key={u.id}>
                  <td>{u.nome}</td>
                  <td>{u.email}</td>
                  <td>{u.telefone || '—'}</td>
                  <td>
                    <span className={`badge ${u.role === 'admin' ? 'bg-danger' : 'bg-primary'}`}>
                      {u.role === 'admin' ? 'Admin' : 'Usuário'}
                    </span>
                  </td>
                  <td>
                    <button className="btn btn-primary btn-sm me-2" onClick={() => handlePrepararEdicao(u)}>✏️</button>
                    <button className="btn btn-danger btn-sm" onClick={() => handleExcluir(u.id)}>🗑️</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Usuarios;