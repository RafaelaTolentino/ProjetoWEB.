import { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, getDocs, updateDoc, deleteDoc, doc, setDoc } from 'firebase/firestore';
// Importações necessárias para criar a conta de login (Firebase Auth)
// de um novo usuário a partir desta tela de administração
import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';

// ----------------------------------------------------------------
// Por que existe uma segunda configuração do Firebase aqui?
//
// Quando o admin cadastra um novo usuário, o código precisa chamar
// createUserWithEmailAndPassword — só que essa função, ao criar uma
// conta nova, automaticamente FAZ LOGIN com essa conta na instância
// de Authentication usada. Se fosse usado o `auth` normal (o mesmo
// importado em src/firebase.js, usado pelo resto do site), o admin
// seria deslogado e "se transformaria" no usuário recém-criado!
//
// A solução é inicializar uma SEGUNDA "app" Firebase totalmente
// independente (com a mesma configuração, mas isolada), chamada aqui
// de "SecondaryAuth". A nova conta é criada usando essa instância
// separada (secondaryAuth), então o login automático acontece apenas
// "dentro" dela — a sessão do admin na instância principal (`auth`,
// usada pelo AuthContext) continua intacta.
// ----------------------------------------------------------------
const firebaseConfig = {
  apiKey: "AIzaSyDxnTDZHY-Y9csnbhzuzxmcdLLfsCSLJPI",
  authDomain: "gatiel-fa7d9.firebaseapp.com",
  projectId: "gatiel-fa7d9",
  storageBucket: "gatiel-fa7d9.firebasestorage.app",
  messagingSenderId: "322054187894",
  appId: "1:322054187894:web:618c4eb3098f5d36222857"
};

// "SecondaryAuth" é só um nome identificador para essa segunda
// instância — precisa ser diferente do nome usado internamente pela
// instância principal do Firebase, para não dar conflito
const secondaryApp = initializeApp(firebaseConfig, "SecondaryAuth");
const secondaryAuth = getAuth(secondaryApp);

// Página administrativa de gestão de usuários: cadastra novas contas
// (criando tanto no Firebase Authentication quanto no Firestore),
// edita dados de usuários existentes, define o nível de permissão
// (usuário comum ou administrador) e permite excluir usuários.
function Usuarios() {
  const [usuarios, setUsuarios]   = useState([]);   // lista de usuários carregada do Firestore
  const [editando, setEditando]   = useState(null);  // usuário em edição (null = modo "cadastrar novo")
  // Campos do formulário
  const [nome, setNome]           = useState('');
  const [email, setEmail]         = useState('');
  const [senha, setSenha]         = useState('');     // só usada ao criar um usuário novo
  const [telefone, setTelefone]   = useState('');
  const [role, setRole]           = useState('user'); // nível de permissão escolhido (padrão: usuário comum)
  const [erro, setErro]           = useState('');
  const [sucesso, setSucesso]     = useState('');

  // Carrega todos os documentos da coleção "usuarios" assim que a
  // página é aberta
  useEffect(() => {
    async function carregar() {
      const snapshot = await getDocs(collection(db, 'usuarios'));
      const lista = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setUsuarios(lista);
    }
    carregar();
  }, []);

  // Limpa todos os campos do formulário e sai do modo de edição
  function limparFormulario() {
    setEditando(null);
    setNome('');
    setEmail('');
    setSenha('');
    setTelefone('');
    setRole('user');
    setErro('');
  }

  // Função chamada ao enviar o formulário — decide se é uma EDIÇÃO ou
  // um CADASTRO NOVO observando se `editando` está preenchido
  async function handleCadastrar(e) {
    e.preventDefault();
    setErro('');
    setSucesso('');

    if (!nome || !email) {
      setErro('Nome e E-mail são obrigatórios.');
      return;
    }

    try {
      if (editando) {
        // ---------- Fluxo de EDIÇÃO ----------
        // Usuário já existe: só atualiza os campos no documento do
        // Firestore (não recria a conta de login, que já existe)
        await updateDoc(doc(db, 'usuarios', editando.id), {
          nome, email, telefone, role
        });
        setUsuarios(usuarios.map(u => u.id === editando.id ? { ...u, nome, email, telefone, role } : u));
        setSucesso('Usuário atualizado com sucesso!');
        limparFormulario();
      } else {
        // ---------- Fluxo de CADASTRO NOVO ----------
        if (!senha || senha.length < 6) {
          setErro('A senha é obrigatória e deve ter pelo menos 6 caracteres para novos usuários.');
          return;
        }

        // 1. Cria a conta de login no Firebase Authentication, usando
        //    a instância secundária explicada no topo do arquivo
        //    (assim o admin não é deslogado)
        const credencial = await createUserWithEmailAndPassword(secondaryAuth, email, senha);
        const uid = credencial.user.uid;

        // 2. Grava o documento de dados no Firestore usando o MESMO
        //    uid gerado pela Authentication como ID do documento —
        //    isso é o que permite, depois, o AuthContext encontrar o
        //    papel (role) certo de cada pessoa ao logar
        const novoUsuario = {
          nome,
          email,
          telefone,
          role, // nível de acesso escolhido pelo administrador no formulário
          criadoEm: new Date().toISOString()
        };

        await setDoc(doc(db, 'usuarios', uid), novoUsuario);
        setUsuarios([{ id: uid, ...novoUsuario }, ...usuarios]);
        setSucesso('Novo usuário registado com sucesso no sistema!');
        limparFormulario();
      }
    } catch (err) {
      console.error(err);
      if (err.code === 'auth/email-already-in-check' || err.code === 'auth/email-already-in-use') {
        setErro('Este e-mail já está em uso por outro usuário.');
      } else {
        setErro('Erro ao processar requisição: ' + err.message);
      }
    }
  }

  // Preenche o formulário com os dados do usuário clicado e entra em
  // modo de edição (o e-mail fica travado — ver input disabled abaixo
  // — porque editar o e-mail de login exigiria mudanças também no
  // Firebase Authentication, que esta tela não faz)
  function handlePrepararEdicao(u) {
    setEditando(u);
    setNome(u.nome || '');
    setEmail(u.email || '');
    setTelefone(u.telefone || '');
    setRole(u.role || 'user');
  }

  // Exclui o usuário, mas só do Firestore (a conta de login no
  // Firebase Authentication permanece existindo, já que apagar contas
  // de Authentication exige privilégios de administrador no backend,
  // não disponíveis aqui no app do navegador)
  async function handleExcluir(id) {
    if (!window.confirm('Deseja excluir este usuário do Banco de Dados?')) return;
    try {
      await deleteDoc(doc(db, 'usuarios', id));
      setUsuarios(usuarios.filter(u => u.id !== id));
    } catch (err) {
      setErro('Erro ao excluir: ' + err.message);
    }
  }

  return (
    <div className="container py-4">
      {/* Formulário de Cadastro / Edição */}
      <div className="card p-4 shadow-sm border-0 mb-4" style={{ borderRadius: 12 }}>
        <h4 className="fw-bold text-dark mb-3">{editando ? '✏️ Editar Usuário' : '🛠️ Cadastrar Novo Usuário'}</h4>
        {erro && <div className="alert alert-danger">{erro}</div>}
        {sucesso && <div className="alert alert-success">{sucesso}</div>}

        <form onSubmit={handleCadastrar} className="row g-3">
          <div className="col-md-6">
            <label className="form-label fw-semibold">Nome *</label>
            <input type="text" className="form-control" value={nome} onChange={e => setNome(e.target.value)} />
          </div>
          <div className="col-md-6">
            <label className="form-label fw-semibold">E-mail *</label>
            {/* Travado durante edição: ver explicação na função handlePrepararEdicao */}
            <input type="email" className="form-control" value={email} onChange={e => setEmail(e.target.value)} disabled={!!editando} />
          </div>
          {/* O campo de senha só aparece no cadastro de um usuário
              novo — ao editar, não é possível (nem necessário) trocar
              a senha por esta tela */}
          {!editando && (
            <div className="col-md-4">
              <label className="form-label fw-semibold">Senha Inicial *</label>
              <input type="password" className="form-control" value={senha} onChange={e => setSenha(e.target.value)} placeholder="Mín. 6 dígitos" />
            </div>
          )}
          <div className={editando ? "col-md-6" : "col-md-4"}>
            <label className="form-label fw-semibold">Telefone</label>
            <input type="text" className="form-control" value={telefone} onChange={e => setTelefone(e.target.value)} />
          </div>
          
          {/* Seletor do nível de permissão: define se a conta poderá
              acessar a área administrativa (veja RotaAdmin.js) */}
          <div className={editando ? "col-md-6" : "col-md-4"}>
            <label className="form-label fw-semibold">Nível de Permissão *</label>
            <select className="form-select" value={role} onChange={e => setRole(e.target.value)}>
              <option value="user">Usuário Comum</option>
              <option value="admin">Administrador</option>
            </select>
          </div>

          <div className="col-12 mt-4">
            <button type="submit" className="btn btn-warning text-white fw-bold me-2">
              {editando ? 'Salvar Alterações' : 'Cadastrar'}
            </button>
            {editando && <button type="button" className="btn btn-light border" onClick={limparFormulario}>Cancelar</button>}
          </div>
        </form>
      </div>

      {/* Tabela com todos os usuários cadastrados */}
      <div className="card p-4 shadow-sm border-0" style={{ borderRadius: 12 }}>
        <h5 className="fw-bold text-dark mb-3">Lista de Utilizadores</h5>
        <div className="table-responsive">
          <table className="table table-hover align-middle">
            <thead className="table-warning">
              <tr>
                <th>Nome</th><th>E-mail</th><th>Telefone</th><th>Permissão</th><th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {usuarios.map(u => (
                <tr key={u.id}>
                  <td>{u.nome}</td>
                  <td>{u.email}</td>
                  <td>{u.telefone || '—'}</td>
                  <td>
                    <span className={`badge ${u.role === 'admin' ? 'bg-danger' : 'bg-primary'}`}>
                      {u.role === 'admin' ? 'Admin' : 'Usuário'}
                    </span>
                  </td>
                  <td>
                    <button className="btn btn-primary btn-sm me-2" onClick={() => handlePrepararEdicao(u)}>✏️</button>
                    <button className="btn btn-danger btn-sm" onClick={() => handleExcluir(u.id)}>🗑️</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Usuarios;