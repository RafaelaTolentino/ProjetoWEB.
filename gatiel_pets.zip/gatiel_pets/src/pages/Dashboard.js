import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { db } from '../firebase';
import { collection, getDocs, query, where } from 'firebase/firestore';

// Página inicial da área administrativa (rota "/admin"). Mostra uma
// saudação e um conjunto de "cards" — atalhos para cada seção do
// painel (Usuários, Pets, Adoções, Requerimentos, Relatório).
function Dashboard() {
  const { usuario } = useAuth();
  const [pendentes, setPendentes] = useState(0); // quantidade de requerimentos com status "Pendente"

  // Ao montar a página, conta quantos requerimentos estão "Pendente"
  // para exibir o aviso (badge) no card de "Requerimentos" — mesma
  // lógica usada no menu (Navbar.js)
  useEffect(() => {
    async function contar() {
      const q = query(collection(db, 'requerimentos'), where('status', '==', 'Pendente'));
      const snap = await getDocs(q);
      setPendentes(snap.size);
    }
    contar();
  }, []);

  // Lista de configuração dos cards exibidos — cada item descreve um
  // atalho: ícone, título, descrição, link de destino, cor e badge
  // (quantidade de pendentes, só usada no card de Requerimentos).
  // Definir essa lista como dados (em vez de escrever 5 blocos de JSX
  // repetidos) permite gerar todos os cards com um único .map() abaixo.
  const cards = [
    { icon: '👤', titulo: 'Usuários',        desc: 'Gerencie os cadastros de usuários',     link: '/admin/usuarios',      cor: '#4e73df', badge: null },
    { icon: '🐶', titulo: 'Pets',            desc: 'Cadastre e edite os pets disponíveis',  link: '/admin/pets',           cor: '#e8973c', badge: null },
    { icon: '📋', titulo: 'Adoções',         desc: 'Acompanhe as adoções realizadas',       link: '/admin/adocoes',        cor: '#1cc88a', badge: null },
    { icon: '📬', titulo: 'Requerimentos',   desc: 'Solicitações enviadas pelos usuários',  link: '/admin/requerimentos',  cor: '#e8973c', badge: pendentes },
    { icon: '📊', titulo: 'Relatório',       desc: 'Veja relatórios e estatísticas',        link: '/admin/relatorio',      cor: '#36b9cc', badge: null },
  ];

  return (
    <div>
      {/* Faixa de boas-vindas no topo, com o nome de quem está logado */}
      <div style={{
        background: 'linear-gradient(135deg, #e8973c22 0%, #fff8f0 100%)',
        borderLeft: '4px solid #e8973c', borderRadius: 8,
        padding: '20px 24px', marginBottom: 32,
      }}>
        <h2 style={{ color: '#e8973c', margin: 0 }}>🐾 Painel Administrativo</h2>
        <p className="text-muted mb-0 mt-1">
          Bem-vindo, <strong>{usuario?.nome}</strong>! Escolha uma seção para gerenciar.
        </p>
      </div>

      {/* Gera um card para cada item da lista `cards` definida acima */}
      <div className="row g-4">
        {cards.map(card => (
          <div className="col-md-4 col-sm-6" key={card.link}>
            <div className="card text-center border-0 shadow-sm h-100 position-relative"
              style={{ borderRadius: 12, transition: 'transform 0.2s' }}
              onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-4px)'} // "levanta" o card ao passar o mouse
              onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}>

              {/* Badge vermelho com a contagem de pendentes — só
                  aparece no card cujo `badge` for maior que 0 (no caso,
                  apenas o card de Requerimentos recebe esse valor) */}
              {card.badge > 0 && (
                <span className="position-absolute top-0 end-0 m-2 badge rounded-pill bg-danger"
                  style={{ fontSize: '0.75rem' }}>
                  {card.badge} pendente{card.badge > 1 ? 's' : ''}
                </span>
              )}

              <div className="card-body p-4 d-flex flex-column align-items-center">
                <div style={{
                  fontSize: '2.8rem', backgroundColor: card.cor + '18', // '18' = transparência leve na cor de fundo (hexadecimal de alpha)
                  borderRadius: '50%', width: 80, height: 80,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16,
                }}>
                  {card.icon}
                </div>
                <h5 className="fw-bold mb-1">{card.titulo}</h5>
                <p className="text-muted small mb-3">{card.desc}</p>
                <Link to={card.link} className="btn mt-auto text-white fw-semibold"
                  style={{ backgroundColor: '#e8973c', borderRadius: 8, minWidth: 120 }}>
                  Acessar
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Dashboard;