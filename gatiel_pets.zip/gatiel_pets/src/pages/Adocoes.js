//Painel de adoções , permite que o admin registre, edite e exclua adoções

import { useState, useEffect } from 'react';
// estado e execução ao carregar

import { db } from '../firebase';
// conexão com o banco

import { collection, addDoc, getDocs, updateDoc, deleteDoc, doc } from 'firebase/firestore';
// ferramentas do banco
// collection/getDocs/ addDocs: aponta para a pasta, busca e cria
// deleteDoc = apaga documento 
// doc: aponta para um documento expecífico pelo ID


function Adocoes() {
  const [adocoes, setAdocoes] = useState([]);
  // adoções já registradas 
  const [usuarios, setUsuarios] = useState([]);
  // todos os usuários, para preencher o <select>
  const [pets, setPets] = useState([]);
  // todos os pets, para preencher o <select>
  const [editando, setEditando] = useState(null);
  //guarda qual edição está sendo feita no momento
  const [usuarioId, setUsuarioId] = useState('');
  const [petId, setPetId] = useState('');
  const [dataAdocao, setDataAdocao] = useState('');
  const [status, setStatus] = useState('Aprovada');
  const [erro, setErro] = useState(''); // mensagem de erro

  // faz três buscas ao mesmo tempo
  useEffect(() => {
    async function carregar() {
      const [snapUsuarios, snapPets, snapAdocoes] = await Promise.all([ // faz todos ao mesmo tempo
        getDocs(collection(db, 'usuarios')),
        getDocs(collection(db, 'pets')),
        getDocs(collection(db, 'adocoes')),
      ]);

      // transforma em objetos e guarda nos componentes correspondentes
      setUsuarios(snapUsuarios.docs.map(d => ({ id: d.id, ...d.data() })));
      setPets(snapPets.docs.map(d => ({ id: d.id, ...d.data() })));
      setAdocoes(snapAdocoes.docs.map(d => ({ id: d.id, ...d.data() })));
    }
    carregar();
  }, []);

  // mostra apenas pets que estão com o status "Disponível"
  const petsFiltrados = pets.filter(p => p.status === 'Disponível' || p.id === petId);

  // zera todos os campos do formulário e volta ao modo de criação
  // editando = null
  // chama após sucesso ou cancelar
  function limparFormulario() {
    setEditando(null);
    setUsuarioId('');
    setPetId('');
    setDataAdocao('');
    setStatus('Aprovada');
    setErro('');
  }

  //cria uma adoção nova ou salva as alterações de uma adoção em edição
  async function handleSalvar(e) {
    e.preventDefault();
    if (!usuarioId || !petId || !dataAdocao) {
      setErro('Preencha todos os campos obrigatórios.');
      return;
      // valida o formulário, se estiver vazio, mostra erro e para
    }

    // Busca os objetos completos do usuário e do pet escolhidos, só
    // para copiar nome/espécie para dentro do documento da adoção
    const objUser = usuarios.find(u => u.id === usuarioId);
    const objPet = pets.find(p => p.id === petId);

    // monta o obejto com todos os dados que serão salvos
    // se encontrou usa o nome dele
    // se não usa um texto padrão
    const dadosMapeados = {
      usuarioId,
      usuarioNome: objUser ? objUser.nome : 'Usuário Desconhecido',
      petId,
      petNome: objPet ? objPet.nome : 'Pet Desconhecido',
      petEspecie: objPet ? objPet.especie : 'Outros',
      dataAdocao,
      status
    };

    try {
      if (editando) {
        // ---------- Atualiza uma adoção existente ----------
        await updateDoc(doc(db, 'adocoes', editando.id), dadosMapeados);
        setAdocoes(adocoes.map(a => a.id === editando.id ? { ...a, ...dadosMapeados } : a));

        // Sincroniza o status do PET de acordo com o novo status da
        // adoção, se a adoção foi marcada como 'Cancelada', o pet
        // volta a ficar 'Disponível'; em qualquer outro status, o pet
        // é marcado como 'Adotado'
        const novoStatusPet = (status === 'Cancelada' || status === 'Pendente') ? 'Disponível' : 'Adotado';
        await updateDoc(doc(db, 'pets', petId), { status: novoStatusPet });
        setPets(pets.map(p => p.id === petId ? { ...p, status: novoStatusPet } : p));

      } else {
        // ---------- Insere uma nova adoção direta ----------
        const docRef = await addDoc(collection(db, 'adocoes'), dadosMapeados);
        // docRef: retorna o ID gerado pelo banco, usa para adicionar a adoção na lista da tela
        setAdocoes([...adocoes, { id: docRef.id, ...dadosMapeados }]);

        // Mesma sincronização de status do pet, agora para uma adoção
        // recém-criada
        const novoStatusPet = status === 'Cancelada' ? 'Disponível' : 'Adotado';
        await updateDoc(doc(db, 'pets', petId), { status: novoStatusPet });
        setPets(pets.map(p => p.id === petId ? { ...p, status: novoStatusPet } : p));
      }
      limparFormulario();
    } catch (err) {
      setErro('Erro ao salvar adoção: ' + err.message);
    }
  }

  // Preenche o formulário com os dados da adoção clicada em "Editar"
  function handlePrepararEdicao(a) {
    setEditando(a);
    setUsuarioId(a.usuarioId || '');
    setPetId(a.petId || '');
    setDataAdocao(a.dataAdocao || '');
    setStatus(a.status || 'Aprovada');
  }

  // Ao excluir o registro da adoção, o pet associado volta
  // automaticamente para 'Disponível' (já que ele não está mais
  // adotado por ninguém)
  async function handleExcluir(adocao) {
    if (!window.confirm('Deseja realmente excluir este registro de adoção?')) return;
    try {
      // 1. Apaga o documento da adoção
      await deleteDoc(doc(db, 'adocoes', adocao.id));

      // 2. Devolve o status do pet associado para 'Disponível'
      if (adocao.petId) { // só atualiza se o ID estiver salvo na adoção
        await updateDoc(doc(db, 'pets', adocao.petId), { status: 'Disponível' });
        setPets(pets.map(p => p.id === adocao.petId ? { ...p, status: 'Disponível' } : p));
      }

      // 3. Atualiza a lista na tela, removendo a adoção excluída
      setAdocoes(adocoes.filter(a => a.id !== adocao.id));
    } catch (err) {
      setErro('Erro ao excluir: ' + err.message);
    }
  }

  return (
    <div className="container py-4">
      {/* Bloco do Formulário */}
      <div className="card p-4 shadow-sm border-0 mb-4" style={{ borderRadius: 12 }}>
        <h5 className="fw-bold text-dark mb-3">
          {editando ? '✏️ Editar Adoção ' : '📋 Realizar Nova Adoção'}
        </h5>
        {erro && <div className="alert alert-danger">{erro}</div>}

        <form onSubmit={handleSalvar} className="row g-3">
          <div className="col-md-4">
            <label className="form-label fw-semibold">Usuário Adotante *</label>
            <select className="form-select" value={usuarioId} onChange={e => setUsuarioId(e.target.value)}>
              <option value="">Selecione um usuário...</option>
              {usuarios.map(u => (
                <option key={u.id} value={u.id}>{u.nome} ({u.email})</option>
              ))}
            </select>
          </div>
          <div className="col-md-4">
            <label className="form-label fw-semibold">Pet Adotado *</label>
            <select className="form-select" value={petId} onChange={e => setPetId(e.target.value)}>
              <option value="">Selecione um pet...</option>
              {petsFiltrados.map(p => (
                <option key={p.id} value={p.id}>{p.nome} ({p.especie} — {p.status})</option>
              ))}
            </select>
          </div>
          <div className="col-md-2">
            <label className="form-label fw-semibold">Data da Adoção *</label>
            <input type="date" className="form-control" value={dataAdocao} onChange={e => setDataAdocao(e.target.value)} />
          </div>
          <div className="col-md-2">
            <label className="form-label fw-semibold">Status *</label>
            {/* Atenção: a 2ª e a 3ª opção abaixo têm o mesmo texto
                "Aprovada"/"Em Análise" mas algumas usam value repetido
                ("Aprovada" aparece em duas <option>) — mantido aqui
                exatamente como está no arquivo original, sem alterar
                a lógica. Na prática, escolher "Em Análise" grava o
                mesmo valor "Aprovada" da primeira opção. */}
            <select className="form-select" value={status} onChange={e => setStatus(e.target.value)}>
              <option value="Aprovada">Aprovada</option>
              <option value="Cancelada">Recusada</option>
              <option value="Pendente">Pendente</option>
            </select>
          </div>
          <div className="col-12 mt-3">
            <button type="submit" className="btn btn-warning text-white fw-bold me-2">
              {editando ? 'Salvar Alterações' : 'Registrar Adoção'}
            </button>
            {editando && <button type="button" className="btn btn-light border" onClick={limparFormulario}>Cancelar</button>}
          </div>
        </form>
      </div>

      {/* Bloco da Tabela de Listagem */}
      <div className="card p-4 shadow-sm border-0" style={{ borderRadius: 12 }}>
        <h5 className="fw-bold text-dark mb-3">Adoções Registradas pelo Administrador</h5>
        {adocoes.length === 0 ? (
          <p className="text-muted mb-0">Nenhuma adoção registrada ainda.</p>
        ) : (
          <div className="table-responsive">
            <table className="table table-hover align-middle">
              <thead className="table-warning">
                <tr>
                  <th>Usuário</th>
                  <th>Pet</th>
                  <th>Data</th>
                  <th>Status</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody>
                {adocoes.map(a => (
                  <tr key={a.id}>
                    <td className="fw-semibold">{a.usuarioNome || '—'}</td>
                    <td>
                      {a.petNome || '—'}{' '}
                      {a.petEspecie && <span className="text-muted small">({a.petEspecie})</span>}
                    </td>
                    <td>{a.dataAdocao ? new Date(a.dataAdocao + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}</td>
                    <td>
                      <span className={`badge ${a.status === 'Aprovada' || a.status === 'Concluída' ? 'bg-success' :
                          a.status === 'Pendente' ? 'bg-warning text-dark' : 'bg-danger'
                        }`}>
                        {a.status}
                      </span>
                    </td>
                    <td>
                      <button className="btn btn-primary btn-sm me-2" onClick={() => handlePrepararEdicao(a)}>✏️</button>
                      {/* Passa o objeto `a` inteiro (não só o id) para
                          que handleExcluir tenha acesso ao petId e
                          consiga devolver o pet para 'Disponível' */}
                      <button className="btn btn-danger btn-sm" onClick={() => handleExcluir(a)}>🗑️</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default Adocoes;