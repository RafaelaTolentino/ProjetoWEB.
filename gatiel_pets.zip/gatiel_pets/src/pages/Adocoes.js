import { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, addDoc, getDocs, updateDoc, deleteDoc, doc } from 'firebase/firestore';

function Adocoes() {
  const [adocoes, setAdocoes]       = useState([]);
  const [usuarios, setUsuarios]     = useState([]);
  const [pets, setPets]             = useState([]);
  const [editando, setEditando]     = useState(null);
  const [usuarioId, setUsuarioId]   = useState('');
  const [petId, setPetId]           = useState('');
  const [dataAdocao, setDataAdocao] = useState('');
  const [status, setStatus]         = useState('Aprovada');
  const [erro, setErro]             = useState('');

  // Carrega os dados iniciais do Firestore
  useEffect(() => {
    async function carregar() {
      const [snapUsuarios, snapPets, snapAdocoes] = await Promise.all([
        getDocs(collection(db, 'usuarios')),
        getDocs(collection(db, 'pets')),
        getDocs(collection(db, 'adocoes')),
      ]);

      setUsuarios(snapUsuarios.docs.map(d => ({ id: d.id, ...d.data() })));
      setPets(snapPets.docs.map(d => ({ id: d.id, ...d.data() })));
      setAdocoes(snapAdocoes.docs.map(d => ({ id: d.id, ...d.data() })));
    }
    carregar();
  }, []);

  // Mostra apenas 'Disponível' ou o pet que já está associado à edição atual
  const petsFiltrados = pets.filter(p => p.status === 'Disponível' || p.id === petId);

  function limparFormulario() {
    setEditando(null);
    setUsuarioId('');
    setPetId('');
    setDataAdocao('');
    setStatus('Aprovada');
    setErro('');
  }

  // Função executada ao enviar o formulário (Salvar / Editar)
  async function handleSalvar(e) {
    e.preventDefault();
    if (!usuarioId || !petId || !dataAdocao) { 
      setErro('Preencha todos os campos obrigatórios.'); 
      return; 
    }

    const objUser = usuarios.find(u => u.id === usuarioId);
    const objPet = pets.find(p => p.id === petId);

    const dadosMapeados = {
      usuarioId,
      usuarioNome: objUser ? objUser.nome : 'Usuário Desconhecido',
      petId,
      petNome: objPet ? objPet.nome : 'Pet Desconhecido',
      petEspecie: objPet ? objPet.especie : 'Outros',
      dataAdocao,
      status
    };

    try {
      if (editando) {
        // Atualiza uma adoção existente
        await updateDoc(doc(db, 'adocoes', editando.id), dadosMapeados);
        setAdocoes(adocoes.map(a => a.id === editando.id ? { ...a, ...dadosMapeados } : a));

        // MODIFICAÇÃO: Se o status mudou para 'Cancelada', libera o pet. Senão, marca como 'Adotado'.
        const novoStatusPet = status === 'Cancelada' ? 'Disponível' : 'Adotado';
        await updateDoc(doc(db, 'pets', petId), { status: novoStatusPet });
        setPets(pets.map(p => p.id === petId ? { ...p, status: novoStatusPet } : p));
        
      } else {
        // Insere uma nova adoção direta
        const docRef = await addDoc(collection(db, 'adocoes'), dadosMapeados);
        setAdocoes([...adocoes, { id: docRef.id, ...dadosMapeados }]);
        
        // Se já criar como Cancelada, o pet continua disponível, caso contrário vai para Adotado
        const novoStatusPet = status === 'Cancelada' ? 'Disponível' : 'Adotado';
        await updateDoc(doc(db, 'pets', petId), { status: novoStatusPet });
        setPets(pets.map(p => p.id === petId ? { ...p, status: novoStatusPet } : p));
      }
      limparFormulario();
    } catch (err) {
      setErro('Erro ao salvar adoção: ' + err.message);
    }
  }

  function handlePrepararEdicao(a) {
    setEditando(a);
    setUsuarioId(a.usuarioId || '');
    setPetId(a.petId || '');
    setDataAdocao(a.dataAdocao || '');
    setStatus(a.status || 'Aprovada');
  }

  // MODIFICAÇÃO: Ao excluir o registro da adoção, o animal volta a ficar disponível
  async function handleExcluir(adocao) {
    if (!window.confirm('Deseja realmente excluir este registro de adoção?')) return;
    try {
      // 1. Deleta a adoção do banco
      await deleteDoc(doc(db, 'adocoes', adocao.id));
      
      // 2. Devolve o status do pet associado para 'Disponível'
      if (adocao.petId) {
        await updateDoc(doc(db, 'pets', adocao.petId), { status: 'Disponível' });
        setPets(pets.map(p => p.id === adocao.petId ? { ...p, status: 'Disponível' } : p));
      }

      // 3. Atualiza a lista na tela
      setAdocoes(adocoes.filter(a => a.id !== adocao.id));
    } catch (err) {
      setErro('Erro ao excluir: ' + err.message);
    }
  }

  return (
    <div className="container py-4">
      {/* Bloco do Formulário */}
      <div className="card p-4 shadow-sm border-0 mb-4" style={{ borderRadius: 12 }}>
        <h5 className="fw-bold text-dark mb-3">
          {editando ? '✏️ Editar Adoção ' : '📋 Realizar Nova Adoção'}
        </h5>
        {erro && <div className="alert alert-danger">{erro}</div>}
        
        <form onSubmit={handleSalvar} className="row g-3">
          <div className="col-md-4">
            <label className="form-label fw-semibold">Usuário Adotante *</label>
            <select className="form-select" value={usuarioId} onChange={e => setUsuarioId(e.target.value)}>
              <option value="">Selecione um usuário...</option>
              {usuarios.map(u => (
                <option key={u.id} value={u.id}>{u.nome} ({u.email})</option>
              ))}
            </select>
          </div>
          <div className="col-md-4">
            <label className="form-label fw-semibold">Pet Adotado *</label>
            <select className="form-select" value={petId} onChange={e => setPetId(e.target.value)}>
              <option value="">Selecione um pet...</option>
              {petsFiltrados.map(p => (
                <option key={p.id} value={p.id}>{p.nome} ({p.especie} — {p.status})</option>
              ))}
            </select>
          </div>
          <div className="col-md-2">
            <label className="form-label fw-semibold">Data da Adoção *</label>
            <input type="date" className="form-control" value={dataAdocao} onChange={e => setDataAdocao(e.target.value)} />
          </div>
          <div className="col-md-2">
            <label className="form-label fw-semibold">Status *</label>
            <select className="form-select" value={status} onChange={e => setStatus(e.target.value)}>
              <option value="Aprovada">Aprovada</option>
              <option value="Cancelada">Recusada</option>
              <option value="Aprovada">Em Análise</option>
            </select>
          </div>
          <div className="col-12 mt-3">
            <button type="submit" className="btn btn-warning text-white fw-bold me-2">
              {editando ? 'Salvar Alterações' : 'Registrar Adoção'}
            </button>
            {editando && <button type="button" className="btn btn-light border" onClick={limparFormulario}>Cancelar</button>}
          </div>
        </form>
      </div>

      {/* Bloco da Tabela de Listagem */}
      <div className="card p-4 shadow-sm border-0" style={{ borderRadius: 12 }}>
        <h5 className="fw-bold text-dark mb-3">Adoções Registradas pelo Administrador</h5>
        {adocoes.length === 0 ? (
          <p className="text-muted mb-0">Nenhuma adoção registrada ainda.</p>
        ) : (
          <div className="table-responsive">
            <table className="table table-hover align-middle">
              <thead className="table-warning">
                <tr>
                  <th>Usuário</th>
                  <th>Pet</th>
                  <th>Data</th>
                  <th>Status</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody>
                {adocoes.map(a => (
                  <tr key={a.id}>
                    <td className="fw-semibold">{a.usuarioNome || '—'}</td>
                    <td>
                      {a.petNome || '—'}{' '}
                      {a.petEspecie && <span className="text-muted small">({a.petEspecie})</span>}
                    </td>
                    <td>{a.dataAdocao ? new Date(a.dataAdocao + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}</td>
                    <td>
                      <span className={`badge ${
                        a.status === 'Aprovada' || a.status === 'Concluída' ? 'bg-success' : 'bg-danger'
                      }`}>
                        {a.status}
                      </span>
                    </td>
                    <td>
                      <button className="btn btn-primary btn-sm me-2" onClick={() => handlePrepararEdicao(a)}>✏️</button>
                      {/* Passamos o objeto 'a' inteiro agora para colher o petId no momento da exclusão */}
                      <button className="btn btn-danger btn-sm" onClick={() => handleExcluir(a)}>🗑️</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default Adocoes;