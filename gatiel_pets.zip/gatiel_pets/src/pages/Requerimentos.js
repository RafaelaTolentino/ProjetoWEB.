//mostra todos os pedidos de adoção enviados pelos 
// usuarios e permite aceiitar ou recusar cada um

import { useState, useEffect } from 'react';
//estado e carregamento da página

import { db } from '../firebase';
// conexão com o banco

import { collection, getDocs, updateDoc, doc } from 'firebase/firestore';
// ferramentas do banco de dados

// Página administrativa de Requerimentos: mostra os pedidos de
// adoção enviados pelos usuários comuns (criados em
// PetsDisponiveis.js) e permite ao admin Aceitar ou Recusar cada um.
function Requerimentos() {
  const [requerimentos, setRequerimentos] = useState([]);
   // todos os requerimentos carregados
  const [carregando, setCarregando]       = useState(true);
  // controla o spinner de carregamento
  const [filtro, setFiltro]               = useState('Pendente'); 
  // aba ativa: Pendente / Aceito / Recusado

  useEffect(() => {
    carregar(); // chama a função carregar
  }, []);

  // busca todos os requerimentos do banco
  //transforma em objetos, ordena do mais recente para o mais antigo
  async function carregar() {
    setCarregando(true);
    const snapshot = await getDocs(collection(db, 'requerimentos'));
    const lista = snapshot.docs
      .map(d => ({ id: d.id, ...d.data() }))
      .sort((a, b) => new Date(b.dataEnvio) - new Date(a.dataEnvio));
    setRequerimentos(lista);
    setCarregando(false);
  }

  async function handleAceitar(req) {
    if (!window.confirm(`Aceitar a solicitação de ${req.usuarioNome} para adotar ${req.petNome}?`)) return;
    // caixaa de confirmação para aceitar a solicitação
    try {
      await updateDoc(doc(db, 'requerimentos', req.id), { status: 'Aceito' });
      // atualiza o campo para aceito
      await updateDoc(doc(db, 'pets', req.petId), { status: 'Adotado' });
      // marca o pet como adotado no banco, some da vitrine no PetsDisponiveis
      setRequerimentos(prev =>
        prev.map(r => r.id === req.id ? { ...r, status: 'Aceito' } : r)
        // atualiza a lista sem ir ao banco, substitui o campo status
      );
    } catch (err) {
      alert('Erro ao aceitar solicitação: ' + err.message);
    }
  }

  // função para recusar
  async function handleRecusar(req) {
    if (!window.confirm(`Recusar a solicitação de ${req.usuarioNome} para adotar ${req.petNome}?`)) return;
    try {
      // 1. Atualiza o requerimento para 'Recusado'
      await updateDoc(doc(db, 'requerimentos', req.id), { status: 'Recusado' });
      
      // 2. Garante que o pet volte para o status 'Disponível'
      await updateDoc(doc(db, 'pets', req.petId), { status: 'Disponível' });
      
      // 3. Atualiza o estado local da tabela de requerimentos na tela
      setRequerimentos(prev =>
        prev.map(r => r.id === req.id ? { ...r, status: 'Recusado' } : r)
      );
    } catch (err) {
      alert('Erro ao recusar solicitação: ' + err.message);
    }
  }

  // Formata uma data ISO
  function formatarData(iso) {
    if (!iso) return '—';
    return new Date(iso).toLocaleDateString('pt-BR');
  }

  // Filtra a lista completa, mostrando só os requerimentos cujo
  // status é igual à aba selecionada (filtro)
  const filtrados = requerimentos.filter(r => r.status === filtro);

  return (
    <div className="container py-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h4 className="fw-bold text-dark mb-0">📬 Requerimentos de Adoção</h4>
        {/* Abas de filtro: Pendentes / Aceitos / Recusados.
            O botão correspondente ao filtro atual fica destacado com
            cor sólida; os demais ficam neutros (btn-light). */}
        <div className="btn-group shadow-sm" role="group">
          <button type="button" className={`btn btn-sm ${filtro === 'Pendente' ? 'btn-warning text-white fw-bold' : 'btn-light text-muted'}`} onClick={() => setFiltro('Pendente')}>⏳ Pendentes</button>
          <button type="button" className={`btn btn-sm ${filtro === 'Aceito' ? 'btn-success fw-bold' : 'btn-light text-muted'}`} onClick={() => setFiltro('Aceito')}>✅ Aceitos</button>
          <button type="button" className={`btn btn-sm ${filtro === 'Recusado' ? 'btn-danger fw-bold' : 'btn-light text-muted'}`} onClick={() => setFiltro('Recusado')}>❌ Recusados</button>
        </div>
      </div>

      {carregando ? (
        <div className="text-center py-5"><div className="spinner-border text-warning" /></div>
      ) : filtrados.length === 0 ? (
        <div className="text-center py-5 bg-white rounded shadow-sm border">
          <p className="text-muted mb-0">Nenhum requerimento encontrado com o status "{filtro}".</p>
        </div>
      ) : (
        <div className="row g-3">
          {filtrados.map(req => (
            <div key={req.id} className="col-12">
              <div className="card p-3 border-0 shadow-sm d-flex flex-row justify-content-between flex-wrap gap-3 align-items-center" style={{ borderRadius: 12 }}>
                <div>
                  <div className="d-flex align-items-center gap-2 mb-2">
                    <span className={`badge ${filtro === 'Pendente' ? 'bg-warning text-dark' : filtro === 'Aceito' ? 'bg-success' : 'bg-danger'}`}>
                      {req.status}
                    </span>
                    <span className="text-muted small">📅 {formatarData(req.dataEnvio)}</span>
                  </div>
                  <h6 className="fw-bold mb-1">
                    👤 {req.usuarioNome} <span className="text-muted fw-normal small">quer adotar</span> 🐾 {req.petNome} <span className="text-muted fw-normal small">({req.petEspecie})</span>
                  </h6>
                  {/* Mensagem opcional escrita pelo usuário ao pedir a adoção */}
                  {req.mensagem && (
                    <p className="text-secondary small mb-0" style={{ fontStyle: 'italic' }}>
                      💬 "{req.mensagem}"
                    </p>
                  )}
                </div>

                {/* Os botões de ação só aparecem enquanto o
                    requerimento estiver Pendente — uma vez Aceito ou
                    Recusado, a decisão já foi tomada */}
                {req.status === 'Pendente' && (
                  <div className="d-flex gap-2">
                    <button className="btn btn-success btn-sm fw-semibold" onClick={() => handleAceitar(req)}>✅ Aceitar</button>
                    <button className="btn btn-danger btn-sm" onClick={() => handleRecusar(req)}>❌ Recusar</button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Requerimentos;