import { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, getDocs } from 'firebase/firestore';

function Relatorio() {
  const [todosRegistros, setTodosRegistros] = useState([]);
  const [carregando, setCarregando]       = useState(true);
  const [filtroStatus, setFiltroStatus]   = useState('Todos');
  const [filtroEspecie, setFiltroEspecie] = useState('Todos');
  const [dataInicio, setDataInicio]       = useState('');
  const [dataFim, setDataFim]             = useState('');

  useEffect(() => {
    async function carregar() {
      // Busca simultaneamente requerimentos e adoções diretas
      const [snapshotReq, snapshotAdoc] = await Promise.all([
        getDocs(collection(db, 'requerimentos')),
        getDocs(collection(db, 'adocoes'))
      ]);

      // Processa requerimentos (feitos pelos usuários na página deles)
      const deRequerimentos = snapshotReq.docs.map(d => {
        const dados = d.data();
        return {
          id: d.id,
          usuarioNome: dados.usuarioNome || '—',
          petNome: dados.petNome || '—',
          petEspecie: dados.petEspecie || 'Outros',
          mensagem: dados.mensagem || '',
          dataEnvio: dados.dataEnvio || '',
          status: dados.status || 'Pendente'
        };
      });

      // MODIFICAÇÃO: Processa adoções feitas direto pelo Admin mostrando o nome correto + (Admin)
      const deAdocoes = snapshotAdoc.docs.map(d => {
        const dados = d.data();
        return {
          id: d.id,
          // Pega o nome do usuário salvo na adoção e concatena o termo " (Admin)"
          usuarioNome: dados.usuarioNome ? `${dados.usuarioNome} (Admin)` : 'Usuário (Admin)',
          petNome: dados.petNome || 'Pet (Admin)',
          petEspecie: dados.petEspecie || 'Outros',
          mensagem: 'Adoção vinculada manualmente pelo Administrador.',
          dataEnvio: dados.dataAdocao ? `${dados.dataAdocao}T00:00:00` : '',
          status: dados.status || 'Aceito'
        };
      });

      // Consolida e ordena do mais recente ao mais antigo
      const final = [...deRequerimentos, ...deAdocoes].sort((a, b) => new Date(b.dataEnvio) - new Date(a.dataEnvio));
      
      setTodosRegistros(final);
      setCarregando(false);
    }
    carregar();
  }, []);

  function badgeStatus(s) {
    if (s === 'Aceito' || s === 'Aprovada' || s === 'Concluída') return 'badge rounded-pill bg-success';
    if (s === 'Recusado' || s === 'Cancelada') return 'badge rounded-pill bg-danger';
    return 'badge rounded-pill bg-warning text-dark';
  }

  function formatarData(iso) {
    if (!iso) return '—';
    return new Date(iso).toLocaleDateString('pt-BR');
  }

  // Filtragem Dinâmica
  const filtrados = todosRegistros.filter(r => {
    if (filtroStatus !== 'Todos') {
      if (filtroStatus === 'Aceito' && r.status !== 'Aceito' && r.status !== 'Aprovada' && r.status !== 'Concluída') return false;
      if (filtroStatus === 'Pendente' && r.status !== 'Pendente') return false;
      if (filtroStatus === 'Recusado' && r.status !== 'Recusado' && r.status !== 'Cancelada') return false;
    }
    if (filtroEspecie !== 'Todos' && r.petEspecie !== filtroEspecie) return false;
    
    if (r.dataEnvio) {
      const dataReg = new Date(r.dataEnvio.substring(0, 10));
      if (dataInicio && dataReg < new Date(dataInicio)) return false;
      if (dataFim && dataReg > new Date(dataFim)) return false;
    }
    return true;
  });

  return (
    <div className="container py-4">
      <h4 className="fw-bold text-dark mb-4">📊 Relatório Gerencial de Adoções</h4>

      <div className="card border-0 shadow-sm p-3 mb-4" style={{ borderRadius: 12 }}>
        <div className="row g-3 align-items-end">
          <div className="col-md-3">
            <label className="form-label small fw-semibold">Status</label>
            <select className="form-select" value={filtroStatus} onChange={e => setFiltroStatus(e.target.value)}>
              <option value="Todos">Todos</option>
              <option value="Aceito">Aceitas / Concluídas</option>
              <option value="Pendente">Pendentes</option>
              <option value="Recusado">Recusadas / Canceladas</option>
            </select>
          </div>
          <div className="col-md-3">
            <label className="form-label small fw-semibold">Espécie</label>
            <select className="form-select" value={filtroEspecie} onChange={e => setFiltroEspecie(e.target.value)}>
              <option value="Todos">Todas</option>
              <option value="Cachorro">Cachorro</option>
              <option value="Gato">Gato</option>
            </select>
          </div>
          <div className="col-md-3">
            <label className="form-label small fw-semibold">De:</label>
            <input type="date" className="form-control" value={dataInicio} onChange={e => setDataInicio(e.target.value)} />
          </div>
          <div className="col-md-3">
            <label className="form-label small fw-semibold">Até:</label>
            <input type="date" className="form-control" value={dataFim} onChange={e => setDataFim(e.target.value)} />
          </div>
        </div>
      </div>

      <div className="card border-0 shadow-sm p-4" style={{ borderRadius: 12 }}>
        {carregando ? (
          <div className="text-center py-4"><div className="spinner-border text-warning" /></div>
        ) : filtrados.length === 0 ? (
          <div className="text-center py-4"><p className="text-muted">Nenhum registro localizado.</p></div>
        ) : (
          <div className="table-responsive">
            <table className="table table-hover align-middle">
              <thead className="table-warning">
                <tr>
                  <th>Solicitante / Adotante</th>
                  <th>Pet</th>
                  <th>Espécie</th>
                  <th>Detalhamento</th>
                  <th>Data</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {filtrados.map(r => (
                  <tr key={r.id}>
                    <td className="fw-semibold">{r.usuarioNome}</td>
                    <td>{r.petNome}</td>
                    <td>{r.petEspecie}</td>
                    <td className="text-muted small">{r.mensagem}</td>
                    <td>{formatarData(r.dataEnvio)}</td>
                    <td><span className={badgeStatus(r.status)}>{r.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default Relatorio;