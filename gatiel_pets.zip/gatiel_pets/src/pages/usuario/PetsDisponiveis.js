import { useState, useEffect } from 'react';
import { db } from '../../firebase';
import { collection, getDocs, addDoc } from 'firebase/firestore';
import { useAuth } from '../../context/AuthContext';
import PetRow from '../../components/PetRow';

function PetsDisponiveis() {
  const [pets, setPets]             = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [modalPet, setModalPet]     = useState(null); // pet selecionado para o modal de solicitação (null = modal fechado)
  const [mensagem, setMensagem]     = useState('');
  const [enviando, setEnviando]     = useState(false);
  const [sucesso, setSucesso]       = useState('');
  const [erro, setErro]             = useState('');
  const { usuario } = useAuth(); // pega o usuário logado, para saber quem está fazendo o pedido

  // Carrega todos os pets, mas mantém na tela só os que têm status
  // "Disponível" (pets já adotados ou em tratamento não aparecem aqui)
  useEffect(() => {
    async function carregar() {
      const snapshot = await getDocs(collection(db, 'pets'));
      const todos = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setPets(todos.filter(p => p.status === 'Disponível'));
      setCarregando(false);
    }
    carregar();
  }, []);

  // Abre o modal de solicitação para o pet escolhido, limpando os
  // campos de mensagem/sucesso/erro de uma eventual abertura anterior
  function abrirModal(pet) {
    setModalPet(pet); setMensagem(''); setSucesso(''); setErro('');
  }

  // Envia o pedido de adoção: cria um novo documento na coleção
  // "requerimentos". Os dados do usuário e do pet (nome, espécie) são
  // copiados diretamente para dentro do documento (em vez de salvar só
  // os IDs) para facilitar a exibição depois, sem precisar fazer
  // buscas extras a cada vez que a lista de pedidos for mostrada.
  async function handleSolicitar() {
    setEnviando(true); setErro('');
    try {
      await addDoc(collection(db, 'requerimentos'), {
        usuarioId:   usuario.id,
        usuarioNome: usuario.nome,
        petId:       modalPet.id,
        petNome:     modalPet.nome,
        petEspecie:  modalPet.especie,
        mensagem:    mensagem.trim(),
        status:      'Pendente',
        dataEnvio:   new Date().toISOString(),
      });
      setSucesso(`Solicitação para adotar ${modalPet.nome} enviada com sucesso!`);
      // Remove o pet da listagem local (ele já foi solicitado por este
      // usuário, então não precisa continuar aparecendo para ele agora)
      setPets(prev => prev.filter(p => p.id !== modalPet.id));
      // Fecha o modal automaticamente depois de 2 segundos, dando tempo
      // de a pessoa ler a mensagem de sucesso
      setTimeout(() => setModalPet(null), 2000);
    } catch (err) {
      setErro('Erro ao enviar. Tente novamente.');
    } finally {
      setEnviando(false);
    }
  }

  return (
    <div>
      <h2>🐾 Pets disponíveis para adoção</h2>
      <p className="text-muted mb-4">Encontre seu novo melhor amigo e envie uma solicitação.</p>

      {carregando ? (
        <div className="text-center py-5">
          <div className="spinner-border" style={{ color: '#e8973c' }} />
          <p className="text-muted mt-2">Carregando pets...</p>
        </div>
      ) : pets.length === 0 ? (
        <div className="text-center py-5 card border-0 shadow-sm" style={{ borderRadius: 12 }}>
          <div style={{ fontSize: '3rem' }}>🐾</div>
          <p className="text-muted mt-2 fw-semibold">Nenhum pet disponível no momento.</p>
          <p className="text-muted small">Volte em breve — novos pets são cadastrados regularmente!</p>
        </div>
      ) : (
        <div className="row">
          {pets.map(pet => (
            // Aqui é onde o PetRow recebe a prop `acoes` customizada,
            // trocando os botões padrão de admin pelo botão "Solicitar adoção"
            <PetRow
              key={pet.id}
              pet={pet}
              acoes={
                <button
                  className="btn w-100 text-white fw-semibold"
                  style={{ backgroundColor: '#e8973c', borderRadius: 8 }}
                  onClick={() => abrirModal(pet)}
                >
                  💛 Solicitar adoção
                </button>
              }
            />
          ))}
        </div>
      )}

      {/* Modal de confirmação — feito manualmente com posicionamento
          fixo e fundo escurecido (overlay), já que o site só importa o
          CSS do Bootstrap (não o JS dele em App.js), então o
          comportamento de modal precisa ser controlado pelo próprio React */}
      {modalPet && (
        <div
          className="modal d-block"
          style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 1050, display: 'flex !important', alignItems: 'center', justifyContent: 'center' }}
          onClick={e => { if (e.target === e.currentTarget) setModalPet(null); }} // clicar fora da caixa fecha o modal
        >
          <div className="modal-dialog modal-dialog-centered" style={{ margin: 'auto' }}>
            <div className="modal-content border-0" style={{ borderRadius: 16 }}>
              <div className="modal-header border-0">
                <h5 className="modal-title fw-bold">
                  💛 Solicitar adoção de <span style={{ color: '#e8973c' }}>{modalPet.nome}</span>
                </h5>
                <button className="btn-close" onClick={() => setModalPet(null)} />
              </div>
              <div className="modal-body">
                {sucesso ? (
                  <div className="alert alert-success text-center">✅ {sucesso}</div>
                ) : (
                  <>
                    {erro && <div className="alert alert-danger small">{erro}</div>}
                    <p className="text-muted small mb-3">
                      Adicione uma mensagem opcional explicando por que você seria um bom lar.
                    </p>
                    <label className="form-label fw-semibold">Mensagem (opcional)</label>
                    <textarea
                      className="form-control"
                      rows={4}
                      placeholder={`Ex: Tenho quintal grande e muito amor para dar ao ${modalPet.nome}...`}
                      value={mensagem}
                      onChange={e => setMensagem(e.target.value)}
                    />
                  </>
                )}
              </div>
              {/* Rodapé com os botões — escondido depois que o pedido é enviado com sucesso */}
              {!sucesso && (
                <div className="modal-footer border-0 pt-0">
                  <button className="btn btn-outline-secondary" onClick={() => setModalPet(null)}>
                    Cancelar
                  </button>
                  <button
                    className="btn text-white fw-semibold"
                    style={{ backgroundColor: '#e8973c' }}
                    onClick={handleSolicitar}
                    disabled={enviando}
                  >
                    {enviando ? 'Enviando...' : '✅ Confirmar solicitação'}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default PetsDisponiveis;