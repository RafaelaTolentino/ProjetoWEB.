/* Mostra todos os pets disponiveis e permite que o usuário logado envie 
uma solicitação de adoção*/
import { useState, useEffect } from 'react';
// useState: atualiza informações modificadas
// useEffect: executa efeitos colaterais

import { db } from '../../firebase';
// importa a conexão com o banco 

import { collection, getDocs, addDoc } from 'firebase/firestore';
// ferramentas do banco de dados

import { useAuth } from '../../context/AuthContext';
// seleciona informações de quem está logado

import PetRow from '../../components/PetRow';
// importa componente visual PetRow, aonde se exibe informações do pet

// função de interface da página
function PetsDisponiveis() {
  const [pets, setPets]             = useState([]);
  // lista que recebe os pets disponiveis para a adoção

  const [carregando, setCarregando] = useState(true);
  // True para carregar os dados com o spinner

  const [modalPet, setModalPet]     = useState(null); 
  // qual pete foi selecionado para a solicitação. Começa com null (nenhum), 
  // quando o usuário clica a caixa recebe a solicitação

  const [mensagem, setMensagem]     = useState('');
  // guarda o texto que o usuário digitou na solicitação

  const [enviando, setEnviando]     = useState(false);
  // controla se o pedido está sendo enviado, evita cliques duplos

  const [sucesso, setSucesso]       = useState('');
  // guarda a mensagem de sucesso após o envio

  const [erro, setErro]             = useState('');
  // guarda mensagem de erro

  const { usuario } = useAuth(); 
  // pega o usuário logado, para saber quem está fazendo o pedido

  // busca todos os documentos da pasta pets no banco
  useEffect(() => {
    async function carregar() {
      const snapshot = await getDocs(collection(db, 'pets'));
      const todos = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      // transforma todos os documentos em um objeto com id + todos os campos salvos

      setPets(todos.filter(p => p.status === 'Disponível'));
      // filtra a lista, mostrando apenas os pets que tem status "Disponível"

      setCarregando(false);
      // carregar() = False
    }
    carregar();
  }, []);

  // chamada quando o usuário clica em "Solicitar adoção"
  function abrirModal(pet) {
    setModalPet(pet); setMensagem(''); setSucesso(''); setErro('');
    // setModelPet: seleciona o pet e abre o modal
    // limpa mensagem de abertura anterior 
    // limpa mensagem de sucesso
    // limpa mensagem de erro
  }

  // quando o usuario confirma a solicitação
  async function handleSolicitar() {
    setEnviando(true); setErro(''); // marca como True e limpa erros antigos
    try {
      await addDoc(collection(db, 'requerimentos'), { // cria documento na pasta requerimentos do banco
        usuarioId:   usuario.id,
        usuarioNome: usuario.nome,
        petId:       modalPet.id,
        petNome:     modalPet.nome,
        petEspecie:  modalPet.especie,
        mensagem:    mensagem.trim(),
        status:      'Pendente', // o admin tem que analizar 
        dataEnvio:   new Date().toISOString(), // data e hora do envio
      });
      setSucesso(`Solicitação para adotar ${modalPet.nome} enviada com sucesso!`);
      // mensagem de sucesso 

      setPets(prev => prev.filter(p => p.id !== modalPet.id));
      // remove o pet da lista visual
      // prev: lista atual // .filter: nova lista sem o pet

      setTimeout(() => setModalPet(null), 2000);
      // fecha o modal em 2 segundos
    } catch (err) {
      setErro('Erro ao enviar. Tente novamente.'); // caso de erro
    } finally { // roda sempre independente de erro, desmarca o enviado e reativa o botão
      setEnviando(false); 
    }
  }

  return (
    <div>
      <h2>🐾 Pets disponíveis para adoção</h2>
      <p className="text-muted mb-4">Encontre seu novo melhor amigo e envie uma solicitação.</p>

      {carregando ? (
        <div className="text-center py-5">
          <div className="spinner-border" style={{ color: '#e8973c' }} /> 
          <p className="text-muted mt-2">Carregando pets...</p>
        </div>
      ) : pets.length === 0 ? (
        <div className="text-center py-5 card border-0 shadow-sm" style={{ borderRadius: 12 }}> 
          <div style={{ fontSize: '3rem' }}>🐾</div>
          <p className="text-muted mt-2 fw-semibold">Nenhum pet disponível no momento.</p>
          <p className="text-muted small">Volte em breve — novos pets são cadastrados regularmente!</p>
        </div>
      ) : (
        <div className="row">
          {pets.map(pet => (
            // Aqui é onde o PetRow recebe a prop `acoes` customizada,
            // trocando os botões padrão de admin pelo botão "Solicitar adoção"
            <PetRow
              key={pet.id}
              pet={pet}
              acoes={
                <button
                  className="btn w-100 text-white fw-semibold"
                  style={{ backgroundColor: '#e8973c', borderRadius: 8 }}
                  onClick={() => abrirModal(pet)}
                >
                  💛 Solicitar adoção
                </button>
              }
            />
          ))}
        </div>
      )}

      {/* Modal de confirmação — feito manualmente com posicionamento
          fixo e fundo escurecido (overlay), já que o site só importa o
          CSS do Bootstrap (não o JS dele em App.js), então o
          comportamento de modal precisa ser controlado pelo próprio React */}
      {modalPet && (
        <div
          className="modal d-block"
          style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 1050, display: 'flex !important', alignItems: 'center', justifyContent: 'center' }}
          onClick={e => { if (e.target === e.currentTarget) setModalPet(null); }} // clicar fora da caixa fecha o modal
        >
          <div className="modal-dialog modal-dialog-centered" style={{ margin: 'auto' }}>
            <div className="modal-content border-0" style={{ borderRadius: 16 }}>
              <div className="modal-header border-0">
                <h5 className="modal-title fw-bold">
                  💛 Solicitar adoção de <span style={{ color: '#e8973c' }}>{modalPet.nome}</span>
                </h5>
                <button className="btn-close" onClick={() => setModalPet(null)} />
              </div>
              <div className="modal-body">
                {sucesso ? (
                  <div className="alert alert-success text-center">✅ {sucesso}</div>
                ) : (
                  <>
                    {erro && <div className="alert alert-danger small">{erro}</div>}
                    <p className="text-muted small mb-3">
                      Adicione uma mensagem opcional explicando por que você seria um bom lar.
                    </p>
                    <label className="form-label fw-semibold">Mensagem (opcional)</label>
                    <textarea
                      className="form-control"
                      rows={4}
                      placeholder={`Ex: Tenho quintal grande e muito amor para dar ao ${modalPet.nome}...`}
                      value={mensagem}
                      onChange={e => setMensagem(e.target.value)}
                    />
                  </>
                )}
              </div>
              {/* Rodapé com os botões — escondido depois que o pedido é enviado com sucesso */}
              {!sucesso && (
                <div className="modal-footer border-0 pt-0">
                  <button className="btn btn-outline-secondary" onClick={() => setModalPet(null)}>
                    Cancelar
                  </button>
                  <button
                    className="btn text-white fw-semibold"
                    style={{ backgroundColor: '#e8973c' }}
                    onClick={handleSolicitar}
                    disabled={enviando}
                  >
                    {enviando ? 'Enviando...' : '✅ Confirmar solicitação'}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default PetsDisponiveis;