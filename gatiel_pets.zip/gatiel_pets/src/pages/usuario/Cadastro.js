import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { auth, db } from '../../firebase';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';

function Cadastro() {
  const [nome, setNome]             = useState('');
  const [email, setEmail]           = useState('');
  const [senha, setSenha]           = useState('');
  const [telefone, setTelefone]     = useState('');
  const [erro, setErro]             = useState('');
  const [sucesso, setSucesso]       = useState(false);
  const [carregando, setCarregando] = useState(false);
  const navigate = useNavigate();

  async function handleCadastrar(e) {
    e.preventDefault();
    setErro('');

    // Validações básicas antes de gastar uma chamada ao Firebase
    if (!nome || !email || !senha) { setErro('Nome, e-mail e senha são obrigatórios.'); return; }
    if (senha.length < 6) { setErro('A senha precisa ter pelo menos 6 caracteres.'); return; } // exigência mínima do Firebase Auth

    setCarregando(true);
    try {
      // 1) Cria a conta de verdade no Firebase Authentication
      //    (e-mail + senha). Isso já loga a pessoa automaticamente no navegador.
      const cred = await createUserWithEmailAndPassword(auth, email, senha);

      // 2) Salva os dados complementares (nome, telefone, papel) no
      //    Firestore, usando o mesmo uid da conta criada como ID do documento
      await setDoc(doc(db, 'usuarios', cred.user.uid), {
        nome,
        email,
        telefone,
        role:      'user', // todo auto-cadastro nasce como usuário comum
        criadoEm:  new Date().toISOString(),
      });

      // 3) Não chama login() manualmente aqui: o onAuthStateChanged
      //    dentro do AuthContext.js vai detectar a nova sessão criada no
      //    passo 1 e preencher o estado "usuario" automaticamente.
      setSucesso(true);
      // Espera 1,2s (tempo para o usuário ver a mensagem de sucesso e
      // para o AuthContext terminar de processar a sessão) antes de navegar
      setTimeout(() => navigate('/user/pets'), 1200);
    } catch (err) {
      const mapa = {
        'auth/email-already-in-use': 'Este e-mail já está cadastrado. Faça login.',
        'auth/invalid-email':        'E-mail inválido.',
      };
      setErro(mapa[err.code] || 'Erro ao criar conta. Tente novamente.');
    } finally {
      setCarregando(false);
    }
  }

  return (
    <div className="d-flex align-items-center justify-content-center min-vh-100"
      style={{ background: '#fff8f0' }}>
      <div className="card border-0 shadow p-4" style={{ width: 460, borderRadius: 16 }}>

        <div className="text-center mb-4">
          <div style={{ fontSize: '2.5rem' }}>🐾</div>
          <h3 className="fw-bold" style={{ color: 'rgb(235, 167, 104)' }}>Criar conta</h3>
          <p className="text-muted small">Cadastre-se para solicitar adoções</p>
        </div>

        {sucesso && <div className="alert alert-success text-center">✅ Conta criada! Redirecionando...</div>}
        {erro    && <div className="alert alert-danger small py-2">⚠️ {erro}</div>}

        <form onSubmit={handleCadastrar}>
          <div className="mb-3">
            <label className="form-label fw-semibold">Nome completo *</label>
            <input className="form-control" value={nome}
              onChange={e => setNome(e.target.value)} placeholder="Seu nome completo" />
          </div>
          <div className="mb-3">
            <label className="form-label fw-semibold">E-mail *</label>
            <input type="email" className="form-control" value={email}
              onChange={e => setEmail(e.target.value)} placeholder="email@exemplo.com" />
          </div>
          <div className="mb-3">
            <label className="form-label fw-semibold">Senha * <span className="fw-normal text-muted">(mín. 6 caracteres)</span></label>
            <input type="password" className="form-control" value={senha}
              onChange={e => setSenha(e.target.value)} placeholder="••••••" />
          </div>
          <div className="mb-4">
            <label className="form-label fw-semibold">Telefone</label>
            <input className="form-control" value={telefone}
              onChange={e => setTelefone(e.target.value)} placeholder="(11) 99999-0000" />
          </div>
          <button type="submit" className="btn w-100 text-white fw-bold"
            style={{ backgroundColor: 'rgb(235, 167, 104)', borderRadius: 8 }}
            disabled={carregando}>
            {carregando ? 'Criando conta...' : '✅ Criar conta'}
          </button>
        </form>

        <p className="text-center text-muted small mt-3 mb-0">
          Já tem conta?{' '}
          <Link to="/login" style={{ color: 'rgb(235, 167, 104)', fontWeight: 600 }}>Fazer login</Link>
        </p>
      </div>
    </div>
  );
}

export default Cadastro;