/*
É a página onde o usuário logado vê tudo relacionado às suas adoções
tanto os pedidos que ele mesmo enviou
quanto adoções que o administrador registrou diretamente no nome dele.
 */

import { useState, useEffect } from 'react'; 
// useState: variáveis que aturalizam automaticamente
// useEffect: executa código de ações que afetam algo fora do componente

import { db } from '../../firebase';
// importa conecção com o banco de dados

import { collection, getDocs, query, where } from 'firebase/firestore';
// collection: aponta para a pasta no banco de dados
// getsDocs: busca os documentos da pasta
// query: monta a pesquisa
// where: define a condição da pesquisa

import { useAuth } from '../../context/AuthContext';
// Hook personalizado que da acesso ao usuário logado

// MeusPedidos: retorna a interface visual, o React a chama sempre que MeusPedidos é acessada
function MeusPedidos() {

  const [pedidos, setPedidos]       = useState([]); 
  // pedidos: array que guarda requerimentos + adoções diretas
  // setPedidos: atualiza e faz a tela redesenhar

  const [carregando, setCarregando] = useState(true);
  //carregando: começa True para mostrar o spinner carregando os dados
  // vira False quando a página é carregada

  const { usuario } = useAuth(); 
  // pega o usuário logado do AuthContext. ID = primary key

  // quando o componente aparece na tela ele executa a função carregar(), se o id mudar, executa denovo 
  useEffect(() => {
    async function carregar() { // async espera respostas do banco de dados
      if (!usuario?.id) return; // segurança: só busca se já houver um usuário logado conhecido

      // busca na pasta requerimento aonde o campo usuarioID seja igual ao usuário logado
      const qReq = query(
        collection(db, 'requerimentos'), 
        where('usuarioId', '==', usuario.id));
      // preparo da consulta

      // adoções feitas pelo administrador 
      const qAdoc = query(
        collection(db, 'adocoes'), 
        where('usuarioId', '==', usuario.id));

      // Promise.all: dispara as duas consultas ao mesmo tempo 
      const [snapReq, snapAdoc] = await Promise.all([ //await: espera terminar para continuar
        // snapReq: resultado dos requerimentos
        // snapAdoc: resultado das adoções
    
        getDocs(qReq),
        getDocs(qAdoc)
      ]);

      // para cada documento encontrado cria um objeto com: 
      const listaReq = snapReq.docs.map(d => ({
        id: d.id, // código único
        origem: 'requerimento', // etiqueta de onde veio
        ...d.data() // todos os campos que estão salvos(nome, data, status, etc)
      }));

      // fal o mesmo da função acima agora para as adoções 
      const listaAdoc = snapAdoc.docs.map(d => {
        const dados = d.data();
        return {
          id: d.id,
          origem: 'direta',
          petNome: dados.petNome || 'Pet Associado', 
          petEspecie: dados.petEspecie || '—',
          dataEnvio: dados.dataAdocao ? `${dados.dataAdocao}T00:00:00` : new Date().toISOString(),
          status: dados.status || 'Aprovada',
          mensagem: 'Adoção registrada diretamente pelo administrador.'
        };
      });

      // junta a listaReq e listaAdoc em uma só, ordenda da mais recente para a mais antiga
      const unificada = [...listaReq, ...listaAdoc].sort((a, b) => new Date(b.dataEnvio) - new Date(a.dataEnvio));
      setPedidos(unificada); // adiciona em pedidos
      setCarregando(false); // muda o carregamento para falso
    }
    carregar();
  }, [usuario?.id]); // refaz a busca se o id do usuário logado mudar

  // parte css. recebe o status e devolve um estilo visual
  function badgeStatus(s) {
    if (s === 'Aceito' || s === 'Aprovada' || s === 'Concluída') return 'badge rounded-pill bg-success'; //status positivo
    if (s === 'Recusado' || s === 'Cancelada') return 'badge rounded-pill bg-danger'; // status negativo
    return 'badge rounded-pill bg-warning text-dark'; // status em espera
  }

  // emojis correspondentes ao status
  function iconeStatus(s) {
    if (s === 'Aceito' || s === 'Aprovada' || s === 'Concluída') return '✅';
    if (s === 'Recusado' || s === 'Cancelada') return '❌';
    return '⏳';
  }

  // recebe uma data em formato técnico e transforma no formato legível
  function formatarData(iso) {
    if (!iso) return '—';
    return new Date(iso).toLocaleDateString('pt-BR');
  }

  return (
    <div className="container py-4">
      <h4 className="fw-bold text-dark mb-4">📋 Meus Pedidos & Adoções</h4>

      {carregando ? ( 
        <div className="text-center py-5"> 
          <div className="spinner-border text-warning" /> 
        </div>
      ) : pedidos.length === 0 ? (
        <div className="text-center py-5 bg-white rounded shadow-sm"> 
          <p className="text-muted mb-0">Não possui nenhum requerimento ou adoção ativa.</p>
        </div>
      ) : (
        <div className="d-flex flex-column gap-3"> 
          {pedidos.map(p => (
            <div key={p.id} className="card border-0 shadow-sm p-4" style={{ borderRadius: 12 }}>
              <div className="d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                  <h6 className="fw-bold mb-1">
                    🐾 {p.petNome}
                    {p.petEspecie && <span className="text-muted fw-normal small ms-2">({p.petEspecie})</span>}
                  </h6>
                  <p className="text-muted small mb-1">📅 Data de Registro: {formatarData(p.dataEnvio)}</p>
                  {p.mensagem && (
                    <p className="text-secondary small mb-0" style={{ fontStyle: 'italic' }}>
                      💬 "{p.mensagem}"
                    </p>
                  )}
                </div>
                <div className="text-end">
                  <span className={badgeStatus(p.status)} style={{ fontSize: '0.9rem', padding: '6px 14px' }}>
                    {iconeStatus(p.status)} {p.status}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default MeusPedidos; // disponibiliza a página 