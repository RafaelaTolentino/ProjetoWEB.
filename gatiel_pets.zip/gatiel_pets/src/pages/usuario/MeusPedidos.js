import { useState, useEffect } from 'react';
import { db } from '../../firebase';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { useAuth } from '../../context/AuthContext';

function MeusPedidos() {
  const [pedidos, setPedidos]       = useState([]);
  const [carregando, setCarregando] = useState(true);
  const { usuario } = useAuth();

  useEffect(() => {
    async function carregar() {
      if (!usuario?.id) return;

      // 1. Query para buscar requerimentos criados pelo utilizador
      const qReq = query(collection(db, 'requerimentos'), where('usuarioId', '==', usuario.id));
      
      // 2. Query para buscar adoções diretas registradas pelo Administrador
      const qAdoc = query(collection(db, 'adocoes'), where('usuarioId', '==', usuario.id));

      const [snapReq, snapAdoc] = await Promise.all([
        getDocs(qReq),
        getDocs(qAdoc)
      ]);

      // Mapeia os requerimentos normais
      const listaReq = snapReq.docs.map(d => ({
        id: d.id,
        origem: 'requerimento',
        ...d.data()
      }));

      // Mapeia e adapta o formato das adoções diretas para a mesma interface visual
      const listaAdoc = snapAdoc.docs.map(d => {
        const dados = d.data();
        return {
          id: d.id,
          origem: 'direta',
          petNome: dados.petNome || 'Pet Associado', 
          petEspecie: dados.petEspecie || '—',
          dataEnvio: dados.dataAdocao ? `${dados.dataAdocao}T00:00:00` : new Date().toISOString(),
          status: dados.status || 'Aprovada',
          mensagem: 'Adoção registrada diretamente pelo administrador.'
        };
      });

      // Une as duas listas e ordena pela data mais recente
      const unificada = [...listaReq, ...listaAdoc].sort((a, b) => new Date(b.dataEnvio) - new Date(a.dataEnvio));

      setPedidos(unificada);
      setCarregando(false);
    }
    carregar();
  }, [usuario?.id]);

  function badgeStatus(s) {
    if (s === 'Aceito' || s === 'Aprovada' || s === 'Concluída') return 'badge rounded-pill bg-success';
    if (s === 'Recusado' || s === 'Cancelada') return 'badge rounded-pill bg-danger';
    return 'badge rounded-pill bg-warning text-dark';
  }

  function iconeStatus(s) {
    if (s === 'Aceito' || s === 'Aprovada' || s === 'Concluída') return '✅';
    if (s === 'Recusado' || s === 'Cancelada') return '❌';
    return '⏳';
  }

  function formatarData(iso) {
    if (!iso) return '—';
    return new Date(iso).toLocaleDateString('pt-BR');
  }

  return (
    <div className="container py-4">
      <h4 className="fw-bold text-dark mb-4">📋 Meus Pedidos & Adoções</h4>

      {carregando ? (
        <div className="text-center py-5">
          <div className="spinner-border text-warning" />
        </div>
      ) : pedidos.length === 0 ? (
        <div className="text-center py-5 bg-white rounded shadow-sm">
          <p className="text-muted mb-0">Não possui nenhum requerimento ou adoção ativa.</p>
        </div>
      ) : (
        <div className="d-flex flex-column gap-3">
          {pedidos.map(p => (
            <div key={p.id} className="card border-0 shadow-sm p-4" style={{ borderRadius: 12 }}>
              <div className="d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                  <h6 className="fw-bold mb-1">
                    🐾 {p.petNome}
                    {p.petEspecie && <span className="text-muted fw-normal small ms-2">({p.petEspecie})</span>}
                  </h6>
                  <p className="text-muted small mb-1">📅 Data de Registro: {formatarData(p.dataEnvio)}</p>
                  {p.mensagem && (
                    <p className="text-secondary small mb-0" style={{ fontStyle: 'italic' }}>
                      💬 "{p.mensagem}"
                    </p>
                  )}
                </div>
                <div className="text-end">
                  <span className={badgeStatus(p.status)} style={{ fontSize: '0.9rem', padding: '6px 14px' }}>
                    {iconeStatus(p.status)} {p.status}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default MeusPedidos;