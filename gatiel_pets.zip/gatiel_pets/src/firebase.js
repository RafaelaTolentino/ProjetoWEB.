import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore'; // o banco de dados (Firestore)
import { getAuth, GoogleAuthProvider } from 'firebase/auth'; // o sistema de login

// Dados de identificação do projeto Firebase na nuvem.
// Essas chaves NÃO são secretas como uma senha — são públicas por design
// no Firebase (qualquer app web expõe essas chaves no navegador); a
// segurança real de quem pode ler/escrever fica nas regras do
// firestore.rules, não aqui.
const firebaseConfig = {
  apiKey: "AIzaSyDxnTDZHY-Y9csnbhzuzxmcdLLfsCSLJPI",
  authDomain: "gatiel-fa7d9.firebaseapp.com",
  projectId: "gatiel-fa7d9",
  storageBucket: "gatiel-fa7d9.firebasestorage.app",
  messagingSenderId: "322054187894",
  appId: "1:322054187894:web:618c4eb3098f5d36222857",
  measurementId: "G-XXC4NQKZMB"
};

// Inicializa a conexão do app com o projeto Firebase configurado acima
const app = initializeApp(firebaseConfig);

// Exporta os "atalhos" que serão importados em todo o resto do código:
export const db              = getFirestore(app); // referência ao banco de dados
export const auth            = getAuth(app);       // referência ao sistema de autenticação
export const googleProvider  = new GoogleAuthProvider(); // configuração do botão "Entrar com Google"

export default app;