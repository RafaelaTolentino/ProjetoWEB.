import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
// ADICIONE ESTA LINHA AQUI:
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

// Fonte global: Baloo 2 para toda a aplicação
const style = document.createElement('style');
style.textContent = `
  *, *::before, *::after {
    font-family: 'Baloo 2', cursive !important;
  }
  h1, h2, h3, h4, h5, h6 {
    font-weight: 700 !important;
  }
  .fw-bold    { font-weight: 700 !important; }\n  .fw-semibold{ font-weight: 600 !important; }\n  .fw-normal  { font-weight: 400 !important; }\n  small, .small { font-size: 0.85rem; }\n`;
document.head.appendChild(style);

ReactDOM.createRoot(document.getElementById('root')).render(<App />);