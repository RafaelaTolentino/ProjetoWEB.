// Ponto de entrada da aplicação: é o primeiro arquivo JavaScript que
// realmente executa quando o site é aberto no navegador. Sua única
// responsabilidade é "plugar" o componente <App /> (que contém todas
// as rotas e páginas) dentro da <div id="root"> que existe no
// public/index.html.

import React from 'react';
import ReactDOM from 'react-dom/client'; // API moderna do React 18+ para criar a "raiz" de renderização
import App from './App';

// Importa o JAVASCRIPT do Bootstrap (não confundir com o CSS, que é
// importado separadamente dentro de App.js). Esse JS é necessário
// para que componentes interativos do Bootstrap baseados em atributos
// data-bs-* funcionem — por exemplo, o botão de menu "hambúrguer"
// (navbar-toggler) usado em Navbar.js e NavbarUsuario.js depende dele
// para abrir/fechar o menu em telas pequenas.
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

// ----------------------------------------------------------------
// Injeta um bloco de CSS global diretamente no <head> da página, em
// tempo de execução (sem precisar de um arquivo .css separado).
// Isso garante que TODO elemento do site (textos, títulos, botões)
// use a fonte "Baloo 2" (carregada no public/index.html via Google
// Fonts) e define os pesos de fonte usados pelas classes utilitárias
// do Bootstrap (fw-bold, fw-semibold, fw-normal), além de um tamanho
// padrão menor para textos com a classe "small".
// ----------------------------------------------------------------
const style = document.createElement('style');
style.textContent = `
  *, *::before, *::after {
    font-family: 'Baloo 2', cursive !important;
  }
  h1, h2, h3, h4, h5, h6 {
    font-weight: 700 !important;
  }
  .fw-bold    { font-weight: 700 !important; }\n  .fw-semibold{ font-weight: 600 !important; }\n  .fw-normal  { font-weight: 400 !important; }\n  small, .small { font-size: 0.85rem; }\n`;
document.head.appendChild(style); // adiciona a tag <style> criada acima ao <head> do documento

// Cria a "raiz" do React dentro do elemento com id="root" (definido em
// public/index.html) e manda renderizar o componente <App /> dentro
// dela — é esse comando que efetivamente "liga" o site.
ReactDOM.createRoot(document.getElementById('root')).render(<App />);