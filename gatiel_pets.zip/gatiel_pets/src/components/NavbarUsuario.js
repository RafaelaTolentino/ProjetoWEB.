import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function NavbarUsuario() {
  const { usuario, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  function handleLogout() { 
    logout(); 
    navigate('/login'); 
  }

  function ativo(path) {
    return location.pathname === path
      ? { color: '#e8973c', fontWeight: '700', borderBottom: '3px solid #e8973c', paddingBottom: 2 }
      : { color: '#555' };
  }

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-white py-3"
      style={{ boxShadow: '0 8px 15px rgba(123,122,122,0.15)' }}>
      <div className="container">

        {/* Logo */}
        <Link className="navbar-brand fw-bold" to="/user/pets" style={{ color: '#e8973c', fontSize: '1.3rem' }}>
          🐾 Gatiel Pets
        </Link>

        {/* Botão do Menu Hambúrguer (Aparece em telas menores) */}
        <button className="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#menuUsuario">
          <span className="navbar-toggler-icon"></span>
        </button>

        {/* Conteúdo Retrátil do Menu */}
        <div className="collapse navbar-collapse justify-content-between" id="menuUsuario">
          <div className="navbar-nav gap-3 my-3 my-lg-0 ms-lg-4">
            <Link className="nav-link px-1" to="/user/pets" style={ativo('/user/pets')}>🐶 Pets disponíveis</Link>
            <Link className="nav-link px-1" to="/user/meus-pedidos" style={ativo('/user/meus-pedidos')}>📋 Meus pedidos</Link>
          </div>

          {/* Seção de Perfil e Botão Sair */}
          <div className="d-flex align-items-center flex-wrap gap-3 pt-3 pt-lg-0 border-top border-lg-0">
            <span className="text-muted small">
              Olá, <strong style={{ color: '#e8973c' }}>{usuario?.nome}</strong>
            </span>
            <button className="btn btn-outline-danger btn-sm px-3 fw-semibold" onClick={handleLogout} style={{ borderRadius: 8 }}>
              🚪 Sair
            </button>
          </div>
        </div>

      </div>
    </nav>
  );
}

export default NavbarUsuario;