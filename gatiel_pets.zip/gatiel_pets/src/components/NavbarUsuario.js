import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// Menu de navegação (topo da tela) usado nas páginas da área do
// usuário comum (veja o componente PaginaUsuario em App.js).
// É a versão "simplificada" do Navbar.js: tem só os 2 links que o
// usuário comum pode acessar e não precisa contar pendentes (isso é
// uma informação só do admin).
function NavbarUsuario() {
  const { usuario, logout } = useAuth(); // dados de quem está logado + função para deslogar
  const navigate = useNavigate();         // permite mudar de página via código
  const location = useLocation();         // URL atual, usada para destacar o link ativo

  // Desloga o usuário e manda de volta para a tela de login
  function handleLogout() { 
    logout(); 
    navigate('/login'); 
  }

  // Mesma lógica do Navbar.js: devolve o estilo "ativo" (laranja) se o
  // caminho recebido for igual à página atual, ou estilo neutro cinza
  // caso contrário.
  function ativo(path) {
    return location.pathname === path
      ? { color: '#e8973c', fontWeight: '700', borderBottom: '3px solid #e8973c', paddingBottom: 2 }
      : { color: '#555' };
  }

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-white py-3"
      style={{ boxShadow: '0 8px 15px rgba(123,122,122,0.15)' }}>
      <div className="container">

        {/* Logo — leva de volta para a lista de pets disponíveis */}
        <Link className="navbar-brand fw-bold" to="/user/pets" style={{ color: '#e8973c', fontSize: '1.3rem' }}>
          🐾 Gatiel Pets
        </Link>

        {/* Botão do Menu Hambúrguer (aparece em telas menores) */}
        <button className="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#menuUsuario">
          <span className="navbar-toggler-icon"></span>
        </button>

        {/* Conteúdo Retrátil do Menu */}
        <div className="collapse navbar-collapse justify-content-between" id="menuUsuario">
          <div className="navbar-nav gap-3 my-3 my-lg-0 ms-lg-4">
            <Link className="nav-link px-1" to="/user/pets" style={ativo('/user/pets')}>🐶 Pets disponíveis</Link>
            <Link className="nav-link px-1" to="/user/meus-pedidos" style={ativo('/user/meus-pedidos')}>📋 Meus pedidos</Link>
          </div>

          {/* Seção de Perfil e Botão Sair */}
          <div className="d-flex align-items-center flex-wrap gap-3 pt-3 pt-lg-0 border-top border-lg-0">
            <span className="text-muted small">
              Olá, <strong style={{ color: '#e8973c' }}>{usuario?.nome}</strong>
            </span>
            <button className="btn btn-outline-danger btn-sm px-3 fw-semibold" onClick={handleLogout} style={{ borderRadius: 8 }}>
              🚪 Sair
            </button>
          </div>
        </div>

      </div>
    </nav>
  );
}

export default NavbarUsuario;