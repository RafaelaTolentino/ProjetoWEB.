import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// Componente "wrapper": recebe a página real como `children`.
// Se existir um usuário logado, mostra a página normalmente.
// Se não, redireciona para /login.
//
// Observação: nas rotas atuais de App.js, este componente não é usado
// diretamente (lá são usados RotaAdmin e RotaUsuario, que já checam o
// papel específico). Ele fica disponível como um guarda genérico, útil
// se no futuro existir alguma página que qualquer usuário logado
// (admin ou comum) possa acessar.
function RotaProtegida({ children }) {
  const { usuario } = useAuth();
  return usuario ? children : <Navigate to="/login" />;
}

export default RotaProtegida;