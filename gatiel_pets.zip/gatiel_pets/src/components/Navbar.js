import { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { db } from '../firebase';
import { collection, getDocs, query, where } from 'firebase/firestore';

// Menu de navegação (topo da tela) usado em TODAS as páginas da área
// administrativa (veja o componente PaginaAdmin em App.js, que sempre
// renderiza <Navbar /> antes do conteúdo da página).
function Navbar() {
  const { usuario, logout } = useAuth(); // dados de quem está logado + função para deslogar
  const navigate  = useNavigate();        // permite mudar de página via código (ex: depois do logout)
  const location  = useLocation();        // informa qual é a URL atual (para destacar o link ativo)
  const [pendentes, setPendentes] = useState(0); // quantidade de requerimentos com status "Pendente"

  // ----------------------------------------------------------------
  // Sempre que a pessoa navega para outra página (location.pathname
  // muda), busca no Firestore quantos documentos da coleção
  // "requerimentos" têm status == 'Pendente' e guarda esse número em
  // `pendentes`. É esse número que aparece na bolinha vermelha ao
  // lado do link "Requerimentos" no menu, avisando o admin que há
  // pedidos de adoção esperando uma decisão.
  // ----------------------------------------------------------------
  useEffect(() => {
    async function contarPendentes() {
      const q = query(collection(db, 'requerimentos'), where('status', '==', 'Pendente'));
      const snap = await getDocs(q);
      setPendentes(snap.size); // snap.size = quantidade de documentos retornados pela consulta
    }
    contarPendentes();
  }, [location.pathname]); // executa de novo cada vez que a URL muda

  // Desloga o usuário (apaga a sessão no Firebase) e manda de volta
  // para a tela de login
  function handleLogout() { 
    logout(); 
    navigate('/login'); 
  }

  // Recebe o caminho de um link (ex: "/admin/pets") e devolve um
  // objeto de estilo: se esse caminho for igual à página atual,
  // devolve o estilo "ativo" (cor laranja, negrito e linha por baixo);
  // senão, devolve um estilo neutro cinza. É chamada dentro do `style`
  // de cada <Link> do menu.
  function ativo(path) {
    return location.pathname === path
      ? { color: '#e8973c', fontWeight: '700', borderBottom: '3px solid #e8973c', paddingBottom: 2 }
      : { color: '#555' };
  }

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-white py-3"
      style={{ boxShadow: '0 8px 15px rgba(123,122,122,0.15)' }}>
      <div className="container">

        {/* Logo — também funciona como link de volta para o Dashboard */}
        <Link className="navbar-brand fw-bold d-flex align-items-center gap-2" to="/admin" style={{ color: '#e8973c', fontSize: '1.3rem' }}>
          <span>🐾</span>
          <span>Gatiel <span className="text-dark">Admin</span></span>
        </Link>

        {/* Botão do Menu Hambúrguer (aparece em telas menores).
            Os atributos data-bs-toggle/data-bs-target são do
            Bootstrap: ao clicar, ele expande/recolhe a div com
            id="menuAdmin" abaixo — por isso o JS do Bootstrap precisa
            estar importado em src/index.js. */}
        <button className="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#menuAdmin">
          <span className="navbar-toggler-icon"></span>
        </button>

        {/* Conteúdo Retrátil do Menu */}
        <div className="collapse navbar-collapse justify-content-between" id="menuAdmin">

          {/* Links principais — cada um usa ativo(caminho) para se
              destacar visualmente quando é a página atual */}
          <div className="navbar-nav gap-3 my-3 my-lg-0 ms-lg-4">
            <Link className="nav-link px-1" to="/admin" style={ativo('/admin')}>🏠 Início</Link>
            <Link className="nav-link px-1" to="/admin/usuarios" style={ativo('/admin/usuarios')}>👤 Usuários</Link>
            <Link className="nav-link px-1" to="/admin/pets" style={ativo('/admin/pets')}>🐶 Pets</Link>
            <Link className="nav-link px-1" to="/admin/adocoes" style={ativo('/admin/adocoes')}>📋 Adoções</Link>
            <Link className="nav-link px-1 position-relative d-inline-flex align-items-center gap-2" to="/admin/requerimentos" style={ativo('/admin/requerimentos')}>
              📬 Requerimentos
              {/* Bolinha vermelha com a quantidade de pendentes — só
                  aparece se houver pelo menos 1 */}
              {pendentes > 0 && (
                <span className="badge rounded-pill bg-danger" style={{ fontSize: '0.7rem' }}>
                  {pendentes}
                </span>
              )}
            </Link>
            <Link className="nav-link px-1" to="/admin/relatorio" style={ativo('/admin/relatorio')}>📊 Relatório</Link>
          </div>

          {/* Seção de Perfil e Botão Sair */}
          <div className="d-flex align-items-center flex-wrap gap-3 pt-3 pt-lg-0 border-top border-lg-0">
            <span className="text-muted small">
              Olá, <strong style={{ color: '#e8973c' }}>{usuario?.nome}</strong>
            </span>
            <button className="btn btn-outline-danger btn-sm px-3 fw-semibold" onClick={handleLogout} style={{ borderRadius: 8 }}>
              🚪 Sair
            </button>
          </div>
        </div>

      </div>
    </nav>
  );
}

export default Navbar;