import { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { db } from '../firebase';
import { collection, getDocs, query, where } from 'firebase/firestore';

function Navbar() {
  const { usuario, logout } = useAuth();
  const navigate  = useNavigate();
  const location  = useLocation();
  const [pendentes, setPendentes] = useState(0);

  useEffect(() => {
    async function contarPendentes() {
      const q = query(collection(db, 'requerimentos'), where('status', '==', 'Pendente'));
      const snap = await getDocs(q);
      setPendentes(snap.size);
    }
    contarPendentes();
  }, [location.pathname]);

  function handleLogout() { 
    logout(); 
    navigate('/login'); 
  }

  function ativo(path) {
    return location.pathname === path
      ? { color: '#e8973c', fontWeight: '700', borderBottom: '3px solid #e8973c', paddingBottom: 2 }
      : { color: '#555' };
  }

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-white py-3"
      style={{ boxShadow: '0 8px 15px rgba(123,122,122,0.15)' }}>
      <div className="container">

        {/* Logo */}
        <Link className="navbar-brand fw-bold d-flex align-items-center gap-2" to="/admin" style={{ color: '#e8973c', fontSize: '1.3rem' }}>
          <span>🐾</span>
          <span>Gatiel <span className="text-dark">Admin</span></span>
        </Link>

        {/* Botão do Menu Hambúrguer (Aparece em telas menores) */}
        <button className="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#menuAdmin">
          <span className="navbar-toggler-icon"></span>
        </button>

        {/* Conteúdo Retrátil do Menu */}
        <div className="collapse navbar-collapse justify-content-between" id="menuAdmin">
          <div className="navbar-nav gap-3 my-3 my-lg-0 ms-lg-4">
            <Link className="nav-link px-1" to="/admin" style={ativo('/admin')}>🏠 Início</Link>
            <Link className="nav-link px-1" to="/admin/usuarios" style={ativo('/admin/usuarios')}>👤 Usuários</Link>
            <Link className="nav-link px-1" to="/admin/pets" style={ativo('/admin/pets')}>🐶 Pets</Link>
            <Link className="nav-link px-1" to="/admin/adocoes" style={ativo('/admin/adocoes')}>📋 Adoções</Link>
            <Link className="nav-link px-1 position-relative d-inline-flex align-items-center gap-2" to="/admin/requerimentos" style={ativo('/admin/requerimentos')}>
              📬 Requerimentos
              {pendentes > 0 && (
                <span className="badge rounded-pill bg-danger" style={{ fontSize: '0.7rem' }}>
                  {pendentes}
                </span>
              )}
            </Link>
            <Link className="nav-link px-1" to="/admin/relatorio" style={ativo('/admin/relatorio')}>📊 Relatório</Link>
          </div>

          {/* Seção de Perfil e Botão Sair */}
          <div className="d-flex align-items-center flex-wrap gap-3 pt-3 pt-lg-0 border-top border-lg-0">
            <span className="text-muted small">
              Olá, <strong style={{ color: '#e8973c' }}>{usuario?.nome}</strong>
            </span>
            <button className="btn btn-outline-danger btn-sm px-3 fw-semibold" onClick={handleLogout} style={{ borderRadius: 8 }}>
              🚪 Sair
            </button>
          </div>
        </div>

      </div>
    </nav>
  );
}

export default Navbar;