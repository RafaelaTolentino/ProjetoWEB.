import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function RotaAdmin({ children }) {
  const { usuario } = useAuth();

  // 1) Não está logado → manda para o login
  if (!usuario)                 return <Navigate to="/login" />;

  // 2) Está logado, mas não é admin → manda para a área do usuário comum
  if (usuario.role !== 'admin') return <Navigate to="/user/pets" />;

  // 3) Está logado e É admin → libera o acesso à página pedida
  return children;
}

export default RotaAdmin;