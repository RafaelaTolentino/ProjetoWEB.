import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// "Componente guarda" (route guard): em vez de proteger uma página
// inteira copiando a mesma verificação dentro de cada página, este
// componente "embrulha" a página real (recebida via a prop especial
// `children`, que é tudo que for colocado entre <RotaAdmin> e
// </RotaAdmin> em App.js) e decide se ela pode ou não ser exibida.
function RotaAdmin({ children }) {
  const { usuario } = useAuth(); // pega quem está logado (ou null) do contexto global

  // 1) Não está logado → manda para o login
  if (!usuario)                 return <Navigate to="/login" />;

  // 2) Está logado, mas não é admin → manda para a área do usuário comum
  if (usuario.role !== 'admin') return <Navigate to="/user/pets" />;

  // 3) Está logado e É admin → libera o acesso à página pedida,
  //    renderizando normalmente o conteúdo (children) recebido
  return children;
}

export default RotaAdmin;