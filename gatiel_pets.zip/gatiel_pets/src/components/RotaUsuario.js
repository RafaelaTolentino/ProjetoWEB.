import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function RotaUsuario({ children }) {
  const { usuario } = useAuth();

  // 1) Não está logado → manda para o login
  if (!usuario)                return <Navigate to="/login" />;

  // 2) É admin tentando acessar a área de usuário comum → manda de
  //    volta para o painel administrativo (evita o admin "se perder"
  //    na área errada)
  if (usuario.role === 'admin') return <Navigate to="/admin" />;

  // 3) É um usuário comum logado → libera o acesso à página pedida
  return children;
}

export default RotaUsuario;