import { createContext, useContext, useState, useEffect } from 'react';
import { auth, db } from '../firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';

// Cria o "contexto" do React: um canal global que qualquer componente
// pode acessar sem precisar receber a informação por props.
const AuthContext = createContext();

// Componente que "envolve" todo o site (usado em App.js) e fornece os
// dados de autenticação para todos os componentes filhos.
export function AuthProvider({ children }) {
  const [usuario, setUsuario]       = useState(null);  // dados do usuário logado (ou null)
  const [carregando, setCarregando] = useState(true);   // true enquanto o Firebase ainda não respondeu

  // ----------------------------------------------------------------
  // Roda uma única vez (array de dependências vazio []), ao montar o
  // AuthProvider. Registra um "ouvinte" do Firebase que é acionado
  // automaticamente sempre que o estado de login muda: ao logar, ao
  // deslogar, ou até ao recarregar a página (o Firebase lembra a
  // sessão salva no navegador).
  // ----------------------------------------------------------------
  useEffect(() => {
    const cancelar = onAuthStateChanged(auth, async (firebaseUser) => {
      if (!firebaseUser) {
        // Ninguém logado
        setUsuario(null);
        setCarregando(false);
        return;
      }

      // Há uma sessão válida no Firebase Authentication — agora busca
      // os dados extras (nome, papel/role) salvos no Firestore, na
      // coleção "usuarios", usando o uid como identificador do documento.
      const snap = await getDoc(doc(db, 'usuarios', firebaseUser.uid));
      if (snap.exists()) {
        const dados = snap.data();
        setUsuario({
          id:    firebaseUser.uid,
          nome:  dados.nome  || firebaseUser.displayName || 'Usuário',
          email: firebaseUser.email,
          role:  dados.role  || 'user', // se não tiver role salvo, assume 'user'
        });
      } else {
        // Caso raro: existe conta no Authentication mas ainda não existe
        // documento correspondente no Firestore (ex.: algum fluxo que
        // não chegou a salvar o documento). Monta um usuário "user"
        // padrão para não travar a aplicação.
        setUsuario({
          id:    firebaseUser.uid,
          nome:  firebaseUser.displayName || 'Usuário',
          email: firebaseUser.email,
          role:  'user',
        });
      }
      setCarregando(false); // libera a renderização do restante do app
    });

    // Função de "limpeza": quando o AuthProvider for desmontado,
    // cancela o ouvinte para não vazar memória.
    return () => cancelar();
  }, []);

  // Permite logar manualmente "na mão" (sem esperar o onAuthStateChanged
  // disparar de novo) — usado em Login.js logo após o login bem-sucedido,
  // já que naquele momento o código já tem nome/role em mãos.
  function login(user) {
    setUsuario(user);
  }

  // Desloga do Firebase e limpa o estado local
  async function logout() {
    await signOut(auth);
    setUsuario(null);
  }

  // Enquanto ainda não se sabe se há alguém logado, mostra só um
  // spinner central — evita que a tela "pisque" mostrando o login e
  // depois trocando de tela assim que o Firebase responder.
  if (carregando) {
    return (
      <div className="d-flex justify-content-center align-items-center vh-100">
        <div className="spinner-border" style={{ color: '#e8973c' }} />
      </div>
    );
  }

  // Disponibiliza usuario/login/logout para qualquer componente filho
  // que use o hook useAuth()
  return (
    <AuthContext.Provider value={{ usuario, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

// Hook de conveniência: em vez de importar useContext + AuthContext em
// todo arquivo, basta chamar useAuth() e pegar { usuario, login, logout }
export function useAuth() {
  return useContext(AuthContext);
}